/// Author : Zaina Shahid
/// Student ID : 34669919
/// File : Implementation File Date.cpp

#include "Date.h"


Date::Date()
{
    day = 0;
    month = 0;
    year = 0;
}


Date::Date(unsigned  d, unsigned  m, unsigned  y)
{
    day = d;
    month = m;
    year = y;
}

 // Accessors and Mutators

void Date::SetDay(unsigned  d)
{
    day = d;
}
int Date::GetDay() const
{
    return day;
}

void Date::SetMonth(unsigned  m)
{
    month = m;
}

int Date::GetMonth() const
{
    return month;
}

void Date::SetYear(unsigned  y)
{
    year = y;
}

int Date::GetYear() const
{
    return year;
}
