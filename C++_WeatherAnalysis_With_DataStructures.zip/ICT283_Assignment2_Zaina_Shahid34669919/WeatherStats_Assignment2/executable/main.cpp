/// main
/// ICT283 Data Structures and Abstractions : Assignment - 2
/// Updated Weather Stats Using Bst Map and Vector Data Structures for loading data.
/// Author : Zaina Shahid
/// Student ID : 34669919
/// File : Main.cpp


#include "Statistics.h"
#include "OperatorOverload.h"

#include <iostream>
#include <cmath>
#include <string>
#include <fstream>
#include <sstream>
#include <map>

// Function prototypes

// Process the user's menu choice
void ProcessChoice(const std::map<int, std::map<int, Bst<WeatherRecordsType>>>& yearMonthData, int ch);

// Get month input from the user
int monthInput();

// Get year input from the user
int yearInput();

// Read weather data from a file
WeatherLogType readData();

// separator function for clear output
void printSeparator();

int main()
{
    WeatherLogType weather_data = readData();

      if (weather_data.GetSize() == 0)
    {
        std::cout << "No data was loaded. Exiting program." << std::endl;
        return 1;
    }

    Statistics stats;
    std::map<int, std::map<int, Bst<WeatherRecordsType>>> yearMonthData = stats.ProcessData(weather_data); // Get organized data
     // Process and organize data

    int choice;
    while (true)
    {
        std::cout<< "Weather Record Stats Menu:\n";
        std::cout<<"                               \n";
        std::cout<< "1. Average Wind Speed and Sample Standard Deviation For a specified Month and Year.\n";
        std::cout<<"                               \n";
        std::cout<< "2. Average Ambient Air Temperature and Sample Standard Deviation for each Month of a specified Year.\n";
        std::cout<<"                               \n";
        std::cout<< "3. Sample Pearson Correlation Coefficient for a specified Month.\n";
        std::cout<<"                               \n";
        std::cout<< "4. Average Wind speed (km/h), Average Ambient Air Temperature, \n";
        std::cout<< "and Total Solar Radiation in kWh/m2 for each Month of a specified Year (with STDEV and MAD).\n";
        std::cout<<"                               \n";
        std::cout<< "5. Exit the program.\n";
        std::cout<<"                               \n";
        std::cout<< "Enter your choice: ";
        std::cout<<"                               \n";
        std::cin >> choice;

         if(choice == 5)
        {
            std::cout << "Exiting the Program." <<std::endl;
            break;
        }

        ProcessChoice(yearMonthData, choice);  // pass the organized data


    }

    return 0;

}

void printSeparator()
{
    std::cout << "\n----------------------------------------\n";
}

void ProcessChoice(const std::map<int, std::map<int, Bst<WeatherRecordsType>>>& yearMonthData, int ch)
{
    // creating a statistics object
    Statistics stats;
    int year;
    int month;


    switch (ch)
   {
       case 1:
           year = yearInput();
           month = monthInput();
           stats.CalculateAndPrintAverageWindSpeedAndStdDev(yearMonthData,year,month);
           printSeparator();
           break;
       case 2:
           year = yearInput();
           stats.CalculateAndPrintAverageAmbientAirTemperatureAndStdDev(yearMonthData,year);
           printSeparator();
           break;
       case 3:
           month = monthInput();
           stats.CalculateAndPrintCorrelationCoefficients(yearMonthData,month);
           printSeparator();
           break;
       case 4:
           year = yearInput();
           stats.CalculateAndGenerateWindTempSolarReport(yearMonthData, year);
           std::cout << "Report generated: WindTempSolar.csv" << std::endl;
           printSeparator();
           break;
       case 5:
            return;
       default:
             std::cout<< "Invalid Choice. Please Try again." <<std::endl;
             printSeparator();

   }

}


// functions to handle and validate user input for month and year

int monthInput()
 {
    int month;
    std::cout << "Enter the month (1-12): ";
    std::cin >> month;
    while (month < 1 || month > 12)
    {
        std::cout << "Invalid month. Please enter a number between 1 and 12: ";
        std::cin >> month;
    }
    return month;
}


int yearInput()
 {
    int year;
    std::cout << "Enter the Year: ";
    std::cin >> year;
    while (year < 0 || year > 2050)
    {
        std::cout << "Invalid year. Please enter a valid year : ";
        std::cin >> year;
    }
    return year;
}


// updated read data to read multiple files at once

WeatherLogType readData()
{
    // opens the hard coded data_source.txt
    std::string fname;
    std::ifstream DataSourceFile("data/data_source.txt");
    if (!DataSourceFile)
    {
        std::cerr << "Error opening data_source.txt" << std::endl;
        return WeatherLogType(); // return empty WeatherLogType
    }

    // WeatherLogType object is created to store data
    WeatherLogType weatherData;
    int totalRecordsLoaded = 0;

    // Read each file listed in data_source.txt
    while (std::getline(DataSourceFile, fname))
    {
        // Add the directory path to the file name
        fname = "data/" + fname;

        // Skip if the file name is empty (possibly from a blank line in data_source.txt)
        if (fname == "data/")
        {
            continue;
        }

        // Open the CSV file and read the data into the data structure
        std::ifstream file(fname);
        if (!file)
        {
            std::cerr << "Error opening " << fname << std::endl;
            continue; // Skip this file and move on to the next one
        }

        // handle the first line of the file
        bool skipHeader = true;
        std::string line;
        Vector<std::string> ColumnHeaders;
        int wastCol = -1, sCol = -1, srCol = -1, tCol = -1;

        int recordsLoadedFromFile = 0;

        while (std::getline(file, line))
        {
            if (skipHeader)
            {
                skipHeader = false;
                std::istringstream str(line);
                std::string field;
                int colIndex = 0;

                // splits the line by commas and stores each field in ColumnHeaders
                while (std::getline(str, field, ','))
                {
                    ColumnHeaders.Insert(field);
                    if (field == "WAST") wastCol = colIndex;
                    else if (field == "S") sCol = colIndex;
                    else if (field == "SR") srCol = colIndex;
                    else if (field == "T") tCol = colIndex;
                    colIndex++;
                }

                if (wastCol == -1 || sCol == -1 || srCol == -1 || tCol == -1)
                {
                    std::cerr << "Error: Required columns not found" << std::endl;
                    return WeatherLogType();
                }

                continue;
            }

            //istringstream is a stream class that allows us to extract data from a string
            std::istringstream str(line);
            std::string field;

            // creates a WeatherRecordsType object to store data
            WeatherRecordsType weatherRec;
            int currentCol = 0;

            bool isValidRecord = true;

            //this is to skip the records that have empty values and
            //continue processing the next records.
            //the readData function now ignores the records with empty values.

            while (std::getline(str, field, ','))
            {
                if (currentCol == wastCol)
                {

                    if(field.empty())
                    {
                        isValidRecord = false;
                        break;
                    }

                    std::istringstream DateTimeStream(field);

                    try
                    {
                       DateTimeStream >> weatherRec.d >> weatherRec.t;
                    }
                    catch(const std::exception& e)
                    {
                        isValidRecord = false;
                        break;
                    }
                }
                else if (currentCol == sCol)
                {
                    if(field.empty())
                    {
                        isValidRecord = false;
                        break;
                    }
                    try
                    {
                       // using stof to convert to float
                        weatherRec.wind_speed = std::stof(field);
                    }
                    catch (const std::invalid_argument& e)
                    {
                        isValidRecord = false;
                        break; // skip this record
                    }
                }
                else if (currentCol == srCol)
                {
                    if(field.empty())
                    {
                        isValidRecord = false;
                        break;
                    }
                    try
                    {
                       // using stof to convert to float
                        weatherRec.solar_radiations = std::stof(field);
                    }
                    catch (const std::invalid_argument& e)
                    {
                        isValidRecord = false;
                        break; // skip this record
                    }

                }
                else if (currentCol == tCol)
                {
                    if(field.empty())
                    {
                        isValidRecord = false;
                        break;
                    }
                    try
                    {
                       // using stof to convert to float
                        weatherRec.amb_temp= std::stof(field);
                    }
                    catch (const std::invalid_argument& e)
                    {
                        isValidRecord = false;
                        break; // skip this record
                    }
                }

                currentCol++;
            }

            if (currentCol == ColumnHeaders.GetSize() && isValidRecord)
            {
                // Only add the record if we've processed all columns
                weatherData.Insert(weatherRec);
                recordsLoadedFromFile++;
            }



        }

        std::cout << "Loaded " << recordsLoadedFromFile << " records from " << fname << std::endl;
        totalRecordsLoaded += recordsLoadedFromFile;

        file.close(); // Close the CSV file
    }

    std::cout << "Total records loaded: " << totalRecordsLoaded << std::endl;

    DataSourceFile.close(); // Close the data_source.txt file

    return weatherData;
}
