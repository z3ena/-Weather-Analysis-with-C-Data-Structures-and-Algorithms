/**
 * @file Bst.h
 * @author Zaina Shahid
 * student id : 34669919
 * @brief Template Class for a Binary Search Tree Data Structure
 */

#ifndef BST_H
#define BST_H

#include <iostream>

// Declaration of struct to hold data members
template <class T>

       /**
        * @struct BstNode
        * @brief Represents a node in the BST.
        */
struct BstNode
{
    T data;
    BstNode* leftL;
    BstNode* rightL;


        /**
         * @brief Constructor that takes data as an argument.
         * @param item The data to be stored in the node.
         */
    BstNode(const T& item) : data(item), leftL(nullptr), rightL(nullptr) {}
};

template <class T>
class Bst
{
public:
       /**
        * @brief Default constructor.
        * Initializes an empty BST.
        */
    Bst();


       /**
        * @brief Destructor.
        * Deallocates all nodes in the BST.
        */
    ~Bst();


      /**
       * @brief Copy constructor.
       * Creates a new BST as a copy of another.
       * @param other The BST to copy.
       */
    Bst(const Bst<T>& other);



      /**
       * @brief Assignment operator.
       * Assigns one BST to another.
       * @param other The BST to assign from.
       * @return Reference to the assigned BST.
       */
    const Bst<T>& operator=(const Bst& other);



       /**
        * @brief Inserts a new value into the BST.
        * @param value The value to be inserted.
        */
    void Insert_B(const T& item);


       /**
        * @brief Deletes the entire BST.
        */
    void DeleteTree();



       /**
        * @brief Searches for a value in the BST.
        * @param value The value to search for.
        * @return true if the value is found, false otherwise.
        */
    bool Search(T item);



       /**
        * @brief Performs an in-order traversal of the BST.
        */
    void inOrderTraversal(void(*out)(const T&)) const;



       /**
        * @brief Performs an pre-order traversal of the BST.
        */
    void preOrderTraversal(void(*out)(T &data)) const;



       /**
        * @brief Performs an post-order traversal of the BST.
        */
    void postOrderTraversal(void(*out)(T &data)) const;

private:

    // pointer that will store address of the root node
    BstNode<T>* rootPtr;


      /**
       * @brief Recursively destroys the BST.
       * @param p Pointer to the node to be destroyed.
       */
    void destroy(BstNode<T>* p);



      /**
       * @brief Recursively copies a BST.
       * @param copiedTreeRoot Reference to the root pointer of the copied tree.
       * @param otherTreeRoot Pointer to the root of the tree to be copied.
       */
    void copyTree(BstNode<T>* &copiedTreeRoot, const BstNode<T>* otherTreeRoot);



      /**
       * @brief Recursively inserts a new value into the BST.
       * @param node Reference to the node pointer.
       * @param item The value to be inserted.
       */
    void insertRecursive(BstNode<T>*& node, const T& item);



      /**
       * @brief Recursively searches for a value in the BST.
       * @param node Pointer to the node to start the search from.
       * @param item The value to search for.
       * @return true if the value is found, false otherwise.
       */
    bool searchRecursive(BstNode<T>* node, T item);



      /**
       * @brief Recursively performs an in-order traversal of the BST.
       * @param node Pointer to the node to start the traversal from.
       * @param out Function pointer to handle the output of each node's data.
       */
    void inorderR(BstNode<T>* node, void(*out)(const T&)) const;




      /**
       * @brief Recursively performs a pre-order traversal of the BST.
       * @param node Pointer to the node to start the traversal from.
       * @param out Function pointer to handle the output of each node's data.
       */
    void preorderR(BstNode<T>* node, void(*out)(T &data)) const;




      /**
       * @brief Recursively performs a post-order traversal of the BST.
       * @param node Pointer to the node to start the traversal from.
       * @param out Function pointer to handle the output of each node's data.
       */
    void postorderR(BstNode<T>* node, void(*out)(T &data)) const;

};


// actual implementation of the functions

template <class T>
Bst<T>::Bst() : rootPtr(nullptr) {}

// destructor

template <class T>
Bst<T>::~Bst()
{
    destroy(rootPtr);
}

// copy constructor
template <class T>
Bst<T>::Bst(const Bst<T>& other)
{
    if (other.rootPtr == nullptr)
    {
        rootPtr = nullptr;
    }
    else
    {
        copyTree(rootPtr, other.rootPtr);
    }
}

// assignment operator
template <class T>
const Bst<T>& Bst<T>::operator=(const Bst<T>& other)
{
    if (this != &other)
    {
        if (rootPtr != nullptr)
        {
            destroy(rootPtr);
        }
        if (other.rootPtr == nullptr)
        {
            rootPtr = nullptr;
        }
        else
        {
            copyTree(rootPtr, other.rootPtr);
        }
    }
    return *this;
}

// copy method
// Helper function to copy the tree
template <class T>
void Bst<T>::copyTree(BstNode<T>*& copiedTreeRoot, const BstNode<T>* otherTreeRoot)
{
    if (otherTreeRoot == nullptr)
    {
        copiedTreeRoot = nullptr;
    }
    else
    {
        copiedTreeRoot = new BstNode<T>(otherTreeRoot->data);
        copyTree(copiedTreeRoot->leftL, otherTreeRoot->leftL);
        copyTree(copiedTreeRoot->rightL, otherTreeRoot->rightL);
    }
}


// insert data into the tree
template <class T>
void Bst<T>::Insert_B(const T& item)
{
    insertRecursive(rootPtr, item);
}

// search for target data value in the tree
template <class T>
bool Bst<T>::Search(T item)
{
    return searchRecursive(rootPtr, item);
}

// recursive method for insert
template <class T>
void Bst<T>::insertRecursive(BstNode<T>*& node, const T& item)
{
    if (node == nullptr)
    {
        node = new BstNode<T>(item);
    }
    else if (item < node->data)
    {
        insertRecursive(node->leftL, item);
    }
    else if (item > node->data)
    {
        insertRecursive(node->rightL, item);
    }
    else
    {

    }
}

// recursive method for search
template <class T>
bool Bst<T>::searchRecursive(BstNode<T>* node, T item)
{
    if (node == nullptr)
    {
        return false;
    }
    else if (node->data == item)
    {
        return true;
    }
    else if (item < node->data)
    {
        return searchRecursive(node->leftL, item);
    }
    else
    {
        return searchRecursive(node->rightL, item);
    }
}

template <class T>
void Bst<T>::inOrderTraversal(void(*out)(const T&)) const
{
    inorderR(rootPtr, out);
    std::cout << std::endl;
}

template <class T>
void Bst<T>::preOrderTraversal(void(*out)(T &data)) const
{
    preorderR(rootPtr, out);
    std::cout << std::endl;
}

template <class T>
void Bst<T>::postOrderTraversal(void(*out)(T &data)) const
{
    postorderR(rootPtr, out);
    std::cout << std::endl;
}

// helper function for in-order traversal
template <class T>
void Bst<T>::inorderR(BstNode<T>* node, void(*out)(const T&)) const
{
    if (node != nullptr)
    {
        inorderR(node->leftL, out);
        out(node->data);
        inorderR(node->rightL, out);
    }
}

// helper function for pre-order traversal
template <class T>
void Bst<T>::preorderR(BstNode<T>* node, void(*out)(T &data)) const
{
    if (node != nullptr)
    {
        out(node->data);
        preorderR(node->leftL, out);
        preorderR(node->rightL, out);
    }
}

// helper function for post-order traversal
template <class T>
void Bst<T>::postorderR(BstNode<T>* node, void(*out)(T &data)) const
{
    if (node != nullptr)
    {
        postorderR(node->leftL, out);
        postorderR(node->rightL, out);
        out(node->data);
    }
}

// delete tree
template <class T>
void Bst<T>::DeleteTree()
{
    destroy(rootPtr);
    rootPtr = nullptr;
}

// destroy binary tree to which p points
// deletes all nodes in post-order traversal
template <class T>
void Bst<T>::destroy(BstNode<T>* p)
{
    if (p != nullptr)
    {
        destroy(p->leftL);
        destroy(p->rightL);
        delete p;
    }
}

#endif
