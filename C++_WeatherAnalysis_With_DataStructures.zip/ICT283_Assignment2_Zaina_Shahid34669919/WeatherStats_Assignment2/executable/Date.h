/**
 * @file Date.H
 * @author Zaina Shahid
 * student id : 34669919
 * @brief Class for storing date values.
 */

#ifndef DATE_H
#define DATE_H

class Date
{
 public:

          /**
           * @brief Default Constructor for a new Date object and set all variable to 0
           *
           */
    Date();


          /**
           * @brief Constructing a new Date object
           *
           * @param d : day
           * @param m : month
           * @param y : year
           */
    Date(unsigned  d, unsigned  m, unsigned  y);



          /** @brief Acessor / Getter method for day
           *
           * @return int day
           *
           */
     int GetDay() const;




          /** @brief Acessor / Getter  method for month
           *
           * @return int month
           *
           */
    int GetMonth() const;




          /** @brief Acessor / Getter method for year
           *
           * @return int year
           *
           */
    int GetYear() const;




         /** @brief Mutator / setter method to set day
          *
          * @param unsigned int d
          * @return void
          *
          */
    void SetDay(unsigned  d);



        /** @brief Mutator / setter method to set month
         *
         * @param unsigned int m
         * @return void
         *
         */
    void SetMonth(unsigned  m);




        /** @brief Mutator / setter method to set year
         *
         * @param unsigned int y
         *
         * @return void
         *
         */
    void SetYear(unsigned  y);



 private:
    int day;
    int month;
    int year;

};


#endif // DATE_H

