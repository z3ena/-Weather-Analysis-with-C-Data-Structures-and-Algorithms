/**
 * @file Time.h
 * @author Zaina Shahid
 * student id : 34669919
 * @brief Class for storing 24 hour format time values
 */

#ifndef TIME_H
#define TIME_H

class Time
{

 public:

           /**
             * @brief Default Constructor for Time object
             *
             */
     Time();


           /**
             * @brief Constructor for a new Time object
             *
             * @param h
             * @param m
             */
     Time(unsigned  h, unsigned  m);



            /**
             * @brief Acessor / Getter method for Hour
             *
             * @return int
             */
     int GetHour() const;


            /**
             * @brief Acessor / Getter method for Minute
             *
             * @return int
             */
     int GetMinute() const;



            /**
             * @brief Mutator / setter method to set the Hour
             *
             * @param h
             */
     void SetHour(unsigned  h);


            /**
             * @brief Mutator / setter method to set the object
             *
             * @param m
             */
     void SetMinute(unsigned  m);


 private:

     int hour;
     int mins;



};

#endif //TIME_H
