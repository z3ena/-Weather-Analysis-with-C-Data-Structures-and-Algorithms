/// Author : Zaina Shahid
/// Student ID : 34669919
/// File : Implementation File OverloadedOperators.cpp

#include "OperatorOverload.h"



//-----------------------------------
// OVERLOADED OPERATORS FOR I/O
//-----------------------------------

// Converts a Time object to a formatted string "HH:MM".
std::string TimeFormat(const Time& time)
{
    std::string result;
    unsigned int hour = time.GetHour();
    unsigned int mins = time.GetMinute();

    if(hour < 10)
        result += "0" + std::to_string(hour);
    else
        result += std::to_string(hour);

    result += ":";

    if(mins < 10)
        result += "0" + std::to_string(mins);
    else
        result += std::to_string(mins);

    return result;
}


// Converts a Date object to a formatted string DD/MM/YYYY
std::string FullDateFormat(const Date& date)
{
    return std::to_string(date.GetDay()) + "/" +
           std::to_string(date.GetMonth()) + "/" +
           std::to_string(date.GetYear());
}



// Overloaded extraction operator for reading a Date object from input stream
std::istream& operator>>(std::istream& input, Date& D)
 {
    std::string dStr, mStr, yStr;
    unsigned dInt, mInt, yInt;  //store the converted numeric values

    getline(input, dStr, '/');  // using getline to read characters until it encounter '/'
    dInt = std::stoi(dStr);  // stores this substring in Dstr and converts it to an int using stoi and stores it in dInt
    D.SetDay(dInt);

    getline(input, mStr, '/');
    mInt = std::stoi(mStr);
    D.SetMonth(mInt);

    getline(input, yStr, ' ');   // reads until a space character (or end of line)
    yInt = std::stoi(yStr);
    D.SetYear(yInt);

    return input;
}



// Overloaded insertion operator for writing a Date object to an output stream
std::ostream& operator<<(std::ostream& os, const Date& D)
{
    os << FullDateFormat(D);
    return os;
}

// Overloaded extraction operator for reading a Time object from input stream
std::istream& operator>>(std::istream& input, Time& T)
{
    std::string hourStr, minuteStr;
    unsigned hourInt, minuteInt;

    getline(input, hourStr, ':');
    hourInt = std::stoi(hourStr);
    T.SetHour(hourInt);

    getline(input, minuteStr, ',');
    minuteInt = std::stoi(minuteStr);
    T.SetMinute(minuteInt);

    return input;
}

// Overloaded insertion operator for writing a Time object to an output stream
std::ostream& operator<<(std::ostream& os, const Time& T)
 {
    os << TimeFormat(T);
    return os;
}


//-----------------------------------
// DATE COMPARISON OPERATORS
//-----------------------------------
bool operator<(const Date& lhs, const Date& rhs)
{
    if (lhs.GetYear() < rhs.GetYear())
        return true;
    else if (lhs.GetYear() == rhs.GetYear())
    {
        if (lhs.GetMonth() < rhs.GetMonth())
            return true;
        else if (lhs.GetMonth() == rhs.GetMonth())
        {
            if (lhs.GetDay() < rhs.GetDay())
                return true;
        }
    }
    return false;
}

bool operator>(const Date& lhs, const Date& rhs)
{
    if (lhs.GetYear() > rhs.GetYear())
        return true;
    else if (lhs.GetYear() == rhs.GetYear())
    {
        if (lhs.GetMonth() > rhs.GetMonth())
            return true;
        else if (lhs.GetMonth() == rhs.GetMonth())
        {
            if (lhs.GetDay() > rhs.GetDay())
                return true;
        }
    }
    return false;
}



bool operator==(const Date& lhs, const Date& rhs)
{
    return (lhs.GetYear() == rhs.GetYear() && lhs.GetMonth() == rhs.GetMonth() && lhs.GetDay() == rhs.GetDay());
}

bool operator!=(const Date& lhs, const Date& rhs)
{
    return !(lhs == rhs);
}



//-----------------------------------
// TIME COMPARISON OPERATORS
//-----------------------------------
bool operator<(const Time& lhs, const Time& rhs)
{
    if (lhs.GetHour() < rhs.GetHour())
       {
           return true;
       }
    else if (lhs.GetHour() == rhs.GetHour())
    {
        if (lhs.GetMinute() < rhs.GetMinute())
            {
                return true;
            }
    }
    return false;
}

bool operator>(const Time& lhs, const Time& rhs)
 {
    if (lhs.GetHour() > rhs.GetHour())
      {
         return true;
      }
    else if (lhs.GetHour() == rhs.GetHour())
    {
        if (lhs.GetMinute() > rhs.GetMinute())
        {
          return true;
        }

    }
    return false;
}



bool operator==(const Time& lhs, const Time& rhs)
{
    return (lhs.GetHour() == rhs.GetHour() && lhs.GetMinute() == rhs.GetMinute());
}

bool operator!=(const Time& lhs, const Time& rhs)
{
    return !(lhs == rhs);
}

//-----------------------------------
// WEATHER RECORD COMPARISON OPERATORS
//-----------------------------------
bool operator>(const WeatherRecordsType& lhs, const WeatherRecordsType& rhs)
{
    if (lhs.d.GetYear() != rhs.d.GetYear())
        return lhs.d.GetYear() > rhs.d.GetYear();
    if (lhs.d.GetMonth() != rhs.d.GetMonth())
        return lhs.d.GetMonth() > rhs.d.GetMonth();
    if (lhs.d.GetDay() != rhs.d.GetDay())
        return lhs.d.GetDay() > rhs.d.GetDay();
    if (lhs.t.GetHour() != rhs.t.GetHour())
        return lhs.t.GetHour() > rhs.t.GetHour();
    return lhs.t.GetMinute() > rhs.t.GetMinute();
}


bool operator<(const WeatherRecordsType& lhs, const WeatherRecordsType& rhs)
{
    if (lhs.d.GetYear() != rhs.d.GetYear())
        return lhs.d.GetYear() < rhs.d.GetYear();
    if (lhs.d.GetMonth() != rhs.d.GetMonth())
        return lhs.d.GetMonth() < rhs.d.GetMonth();
    if (lhs.d.GetDay() != rhs.d.GetDay())
        return lhs.d.GetDay() < rhs.d.GetDay();
    if (lhs.t.GetHour() != rhs.t.GetHour())
        return lhs.t.GetHour() < rhs.t.GetHour();
    return lhs.t.GetMinute() < rhs.t.GetMinute();
}


bool operator==(const WeatherRecordsType& lhs, const WeatherRecordsType& rhs)
{
    return (lhs.d.GetYear() == rhs.d.GetYear() &&
            lhs.d.GetMonth() == rhs.d.GetMonth() &&
            lhs.d.GetDay() == rhs.d.GetDay() &&
            lhs.t.GetHour() == rhs.t.GetHour() &&
            lhs.t.GetMinute() == rhs.t.GetMinute());
}

bool operator!=(const WeatherRecordsType& lhs, const WeatherRecordsType& rhs)
{
    return !(lhs == rhs);
}


