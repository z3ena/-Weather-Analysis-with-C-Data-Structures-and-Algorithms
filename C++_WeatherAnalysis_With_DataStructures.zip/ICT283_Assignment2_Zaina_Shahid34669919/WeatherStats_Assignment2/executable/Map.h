// minimal but complete encapsulated map class
// uses stl map
//  is not utilized in this assignment

/**
#ifndef MAP_H
#define MAP_H

#include <map>


template <class T, class U>
class Map
{
   public:
       Map(); // default constructor

       bool Map_Insert(const T& key, const U& value);
       bool GetValue(const T& key, U& value) const;
       bool Remove(const T& key);
       bool isEmpty() const;
       int Size() const ;
       bool Contains_Key(const T& key) const;

       typename std::map<T, U>::const_iterator begin() const;
       typename std::map<T, U>::const_iterator end() const;

       typename std::map<T, U>::iterator begin();
       typename std::map<T, U>::iterator end();



   private:
    std::map <T, U> m_map; // uses the STL map internally


};

// implementation of the functions

template<class T, class U>
Map<T,U>::Map()
{


}


template<class T, class U>
bool Map<T,U>::isEmpty() const
{
    return m_map.empty(); //stl function
}


template<class T, class U>
bool Map<T,U>::Map_Insert(const T& key, const U& value)
{
    bool done = true;

    try
    {
        m_map.insert(std::make_pair(key,value));  //stl method
    }
    catch(const std::exception& e)
    {
        std::cerr << "Error inserting into map: " << e.what() << std::endl;
        done = false;
    }

    return done;
}



template<class T, class U>
bool Map<T,U>::GetValue(const T& key, U& value) const
{
    typename std::map<T, U>::const_iterator it = m_map.find(key);
    if(it != m_map.end())
    {
        value = it->second;
        return true;
    }
    else
    {
        return false;
    }
}


template<class T, class U>
bool Map<T,U>::Remove(const T& key)
{
    if(m_map.find(key)!=m_map.end())
    {
        m_map.erase(key);
        return true;
    }
    else
    {
        return false;
    }
}


template<class T, class U>
typename std::map<T, U>::const_iterator Map<T,U>::begin() const
{
    return m_map.begin();
}

template<class T, class U>
typename std::map<T, U>::const_iterator Map<T,U>::end() const
{
    return m_map.end();
}

template<class T, class U>
typename std::map<T, U>::iterator Map<T,U>::begin()
{
    return m_map.begin();
}

template<class T, class U>
typename std::map<T, U>::iterator Map<T,U>::end()
{
    return m_map.end();
}

template<class T, class U>
bool Map<T, U>::Contains_Key(const T& key) const
{
    return m_map.find(key) != m_map.end();
}

#endif // MAP_H

**/
