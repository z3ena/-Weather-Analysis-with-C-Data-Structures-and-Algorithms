/// Author : Zaina Shahid
/// Student ID : 34669919
/// File : Implementation File Time.cpp

#include "Time.h"


Time::Time()
{
    hour = 0;
    mins = 0;
}
Time::Time(unsigned  h, unsigned  m)
{
    hour = h;
    mins = m;
}

int Time::GetHour() const
{
    return hour;
}
int Time::GetMinute() const
{
    return mins;
}

void Time::SetHour(unsigned  h)
{
    hour = h;
}
void Time::SetMinute(unsigned  m)
{
    mins = m;
}
