#ifndef VECTOR_H
#define VECTOR_H


#include <iostream>
#include <string>
#include <vector>


/**
 * @brief Vector class template for storing elements of type T
 *
 * This class implements a dynamic array (vector) data structure that can store
 * elements of any type `T`. It provides methods to insert, remove, and access
 * elements, as well as to manage the size and capacity of the vector.
 *
 * @tparam T The data type of the elements to be stored in the vector.
 */


template <class T>
class Vector
{

 public:

        /**
         * @brief Default constructor.
         *
         * Initializes an empty vector with a default capacity of 1.
         */
      Vector();


        /**
         * @brief Copy constructor.
         *
         * Initializes a new vector by deep copying the contents of another vector.
         *
         * @param other The vector to be copied.
         */
      Vector (const Vector& other);

        /**
         * @brief Destructor.
         *
         * Deallocates the memory used by the vector.
         */
     ~Vector();


        /**
         * @brief Get the current size of the vector.
         *
         * @return The number of elements currently stored in the vector.
         */
     int GetSize() const;


        /**
         * @brief Get the current capacity of the vector.
         *
         * @return The maximum number of elements the vector can hold before resizing.
         */
     int GetCapacity() const;


        /**
         * @brief Assignment operator.
         *
         * Assigns the contents of another vector to this vector.
         *
         * @param vec The vector to be assigned.
         * @return A reference to this vector.
         */
     Vector<T>& operator = (const Vector &vec);


        /**
         * @brief Insert an element into the vector.
         *
         * Adds a new element to the end of the vector. If the vector is full, it
         * will be resized to accommodate the new element.
         *
         * @param val The element to be inserted.
         * @return true if the insertion was successful, false otherwise.
         */
     bool Insert(const T &val);


        /** @brief Retrieves a reference to the element at the specified index (non-const version).
         *
         * @param index The index of the element to access.
         * @return A reference to the element at the specified index.
         * @throw std::out_of_range if the index is out of bounds.
         */
      T& operator[](unsigned int index);



       /** @brief Retrieves a const reference to the element at the specified index (const version).
        *
        * @param index ,The index of the element to access.
        * @return A const reference to the element at the specified index.
        * @throw std::out_of_range if the index is out of bounds.
        */
      const T& operator[](unsigned int index) const;




        /**
         * @brief Remove the last element from the vector.
         *
         * Removes the last element from the vector and decrements the size.
         *
         * @return true if the removal was successful (i.e., the vector was not empty),
         *         false otherwise.
         */
       bool Remove();

private:

   std::vector<T> m_data;

};

#endif // VECTOR_H


// Implementations of the functions

// Default Constructor
template <class T>
Vector<T>::Vector(): m_data()
{

}


// Copy constructor
template <class T>
Vector<T>::Vector(const Vector& other): m_data(other.m_data)
{
  // no copy method vector does it itself

}


// destructor
template <class T>
Vector<T>::~Vector()
{

}


// overloaded assignment operator
template <class T>
Vector<T>& Vector<T>::operator = (const Vector &vec)   //takes reference to another vector obj and
                                                       //returns reference to current obj which is this
{
    m_data = vec.m_data;
    return *this;



}

// getter for size
template <class T>
int Vector<T>::GetSize() const
{
    return m_data.size();
}

// getter for capacity
template <class T>
int Vector<T>::GetCapacity() const
{

    return m_data.capacity();
}

// overloaded [] non const
//operator[] overload allows access and modification of the element at the specified index.
//If the index is out of bounds an exception is thrown.

template <class T>
T& Vector<T>::operator[](unsigned int index)
{
    if (index >= m_data.size())
    {
        std::cout<<"Index out of bounds"<< std::endl;
    }
    return m_data[index];
}

// overload [] const
//operator[] overload does not allow access and modification pf the element at the specified index.
//If the index is out of bounds an exception is thrown.

template <class T>
const T& Vector<T>::operator[](unsigned int index) const
 {
    if (index >= m_data.size())
    {
        std::cout<<"Index out of bounds"<< std::endl;
    }
    return m_data[index];
}


// insert elements in the vector
template <class T>
bool Vector<T>::Insert(const T &val)
{
    m_data.push_back(val);
    return true;
}

// remove the last element from vector
template <class T>
bool Vector<T>::Remove()
{
    if(!m_data.empty())
    {
        m_data.pop_back();
        return true;
    }

    return false;
}
