/// Author : Zaina Shahid
/// Student ID : 34669919
/// File : Implementation File Statistics.cpp

#include "Statistics.h"
#include <iostream>
#include <fstream>
#include <iomanip>
#include <cmath>
#include <map>


/**

  - std::map : used to store weather records organized by year and month
  - BST : a binary search tree used to store and allow efficient traversal of weather records of a specific month
  - Vector : used to store data such as wind speed , temp , solar radiation extracted from the weather records.
  - Static pointers : Ensure the callback functions insert data into the correct vector during BST traversal.

**/

// Initialize static members
// used to point to the current vector being filled with data
// during the BST traversal

Vector<float>* Statistics::speedPtr = nullptr;
Vector<float>* Statistics::tempPtr = nullptr;
Vector<float>* Statistics::solarPtr = nullptr;



// Call Back Functions :
void Statistics::ProcessWindSpeed(const WeatherRecordsType& record)
{
    if (speedPtr)
    {
        speedPtr->Insert(ConvertWindSpeedFromMStoKMH(record.wind_speed));
    }
}


void Statistics::ProcessTemperature(const WeatherRecordsType& record)
{
    if (tempPtr)
    {
        tempPtr->Insert(record.amb_temp);
    }
}


void Statistics::ProcessSolarRadiation(const WeatherRecordsType& record)
{
    if (solarPtr && record.solar_radiations >= 100.0f) // Filter out values less than 100 W/m�
    {
        solarPtr->Insert(ConvertSolarRadiationFromWtoKWH(record.solar_radiations));
    }
}

//calculating the total sum of a Vector of float values
float Statistics::CalculateTotal(const Vector<float>& values)
{
    float sum = 0.0f;
    for (int i = 0; i < values.GetSize(); ++i)
    {
        sum += values[i];
    }
    return sum;
}

//calculating the average
float Statistics::CalculateAvg(const Vector<float>& values)
{

    float total = CalculateTotal(values);
    return total / values.GetSize();

}

//calculating the standard deviation
float Statistics::CalculateStandardDeviation(const Vector<float>& values, float average)
{
    float sum = 0.0f;
    for (int i = 0; i < values.GetSize(); ++i)
    {
        sum += pow(values[i] - average, 2);
    }
    return sqrt(sum / values.GetSize());

}




// Function to calculate the
// sample Pearson Correlation Coefficient
float Statistics::sPCC(const Vector<float>& v1, const Vector<float>& v2) {
    int size1 = v1.GetSize();
    int size2 = v2.GetSize();

    if (size1 == 0 || size2 == 0) {
        std::cerr << "Error: One or both vectors are empty." << std::endl;
        return -1;
    }

    // Determine the minimum size to ensure overlapping data
    int minSize = std::min(size1, size2);

    float sum1 = 0.0;
    float sum2 = 0.0;

    for (int i = 0; i < minSize; ++i) {
        sum1 += v1[i];
        sum2 += v2[i];
    }

    float mean1 = sum1 / minSize;
    float mean2 = sum2 / minSize;

    float numerator = 0.0;
    float denominator1 = 0.0;
    float denominator2 = 0.0;

    for (int i = 0; i < minSize; ++i) {
        numerator += (v1[i] - mean1) * (v2[i] - mean2);
        denominator1 += std::pow(v1[i] - mean1, 2);
        denominator2 += std::pow(v2[i] - mean2, 2);
    }

    // Calculate the Pearson correlation coefficient
    float coefficient = numerator / (std::sqrt(denominator1) * std::sqrt(denominator2));

    return coefficient;
}

// function to calculate the mean absolute deviation
float Statistics:: mad(const Vector<float>& data)
{
    if (data.GetSize() == 0)
    {
        std::cerr << "Error: Cannot calculate MAD for an empty vector." << std::endl;
        return -1;
    }

    double sum = 0.0;
    for (int i = 0; i < data.GetSize(); ++i)
    {
        sum += data[i];
    }
    double mean = sum / data.GetSize();

    double mad_sum = 0.0;
    for (int i = 0; i < data.GetSize(); ++i)
    {
        mad_sum += std::abs(data[i] - mean);
    }

    return mad_sum / data.GetSize();
}


//converts wind speed from meters per second to kilometers
float Statistics::ConvertWindSpeedFromMStoKMH(float windSpeed)
{
    return windSpeed * 3.6f;
}

//converts solar radiation from watts to kilowatt-hours per square meter
float Statistics::ConvertSolarRadiationFromWtoKWH(float solarRadiation)
{
    return solarRadiation * 1.0f / 6.0f / 1000.0f;
}

//converts an integer month to its string representation
std::string Statistics::IntMonthToString(const int &month)
{
    switch (month)
    {
    case 1: return "January";
    case 2: return "February";
    case 3: return "March";
    case 4: return "April";
    case 5: return "May";
    case 6: return "June";
    case 7: return "July";
    case 8: return "August";
    case 9: return "September";
    case 10: return "October";
    case 11: return "November";
    case 12: return "December";
    default:
        std::cout << std::endl << "Error converting int month to string" << std::endl;
    }
}



// populating the map and the bst and processing the data
// Converts a WeatherLogType into a nested map of BSTs categorized by year and month

std::map<int, std::map<int, Bst<WeatherRecordsType>>> Statistics::ProcessData(const WeatherLogType& weatherData)
{

    // a nested map where each year contains a map of months
    // and each month contains a BST of weather records

    std::map<int, std::map<int, Bst<WeatherRecordsType>>> yearMonthData;

    // iterating through each weather record
    for (int i = 0; i < weatherData.GetSize(); ++i)
    {

        // extract year and month from each record
        const WeatherRecordsType& record = weatherData[i];
        int year = record.d.GetYear();
        int month = record.d.GetMonth();

        // insert the record into the corresponding BST in the nested map
         if (yearMonthData.find(year) == yearMonthData.end())
        {
            yearMonthData[year] = std::map<int, Bst<WeatherRecordsType>>();
        }

        if (yearMonthData[year].find(month) == yearMonthData[year].end())
        {
            yearMonthData[year][month] = Bst<WeatherRecordsType>();
        }

        yearMonthData[year][month].Insert_B(record); // inserts into BST


    }

    return yearMonthData;
}


// option 1
// Calculates and prints the average wind speed and its standard deviation.

void Statistics::CalculateAndPrintAverageWindSpeedAndStdDev(const std::map<int, std::map<int, Bst<WeatherRecordsType>>>& yearMonthData, int year, int month)
{

    // check if year exists in the data
    if(yearMonthData.find(year) == yearMonthData.end())
    {
        std::cout << IntMonthToString(month) << " " << year << ": No Data" << std::endl;
        return;
    }

    // get data for the specified year
    const std::map<int, Bst<WeatherRecordsType>>& yearData = yearMonthData.at(year);

    // check if month exists in the data for the specified year
    if(yearData.find(month) == yearData.end())
    {
        std::cout << IntMonthToString(month) << " " << year << ": No Data" << std::endl;
        return;
    }

    // get the bst for that month
    const Bst<WeatherRecordsType>& monthData = yearData.at(month);

    // stores the wind speed data extracted from bst during traversal
    Vector<float> Speed;

    // static pointer
    speedPtr = &Speed;

    // Traverse the BST in-order to get the sorted data
     monthData.inOrderTraversal(ProcessWindSpeed);


     // reset static pointer to avoid unintended use
     speedPtr = nullptr;


    float avg = CalculateAvg(Speed);
    float sstd = CalculateStandardDeviation(Speed, avg);

    std::cout << IntMonthToString(month) << " " << year << ":" << std::endl;
    std::cout << "Average speed: " << std::fixed << std::setprecision(1) << avg << " km/h" << std::endl;
    std::cout << "Sample stdev: " << std::fixed << std::setprecision(1) << sstd << std::endl;



}


//option 2
void Statistics::CalculateAndPrintAverageAmbientAirTemperatureAndStdDev(const std::map<int, std::map<int, Bst<WeatherRecordsType>>>& yearMonthData, int year)
{
    if(yearMonthData.find(year) == yearMonthData.end())
    {
        std::cout << year << std::endl;
        std::cout << "No Data" << std::endl;
        return;
    }

    const std::map<int, Bst<WeatherRecordsType>>& yearData = yearMonthData.at(year);

    std::cout << year << std::endl;
    bool dataFound = false;


    // iterate through each month
    for (int month = 1; month <= 12; ++month)
    {
        if(yearData.find(month) == yearData.end())
        {
            // Print "No Data" if the month is not in the data
            std::cout << IntMonthToString(month) << ": No Data" << std::endl;
            continue;
        }

        const Bst<WeatherRecordsType>& monthData = yearData.at(month);

        // stores the temperature data extracted from the bst during traversal.
        Vector<float> temp;

        // static pointer
        tempPtr = &temp;



    //Traverse the BST in-order to get the sorted data
       monthData.inOrderTraversal(ProcessTemperature);

       tempPtr = nullptr;

       if (temp.GetSize() > 0)
        {
            dataFound = true;
            float avg = CalculateAvg(temp);
            float sstd = CalculateStandardDeviation(temp, avg);

            std::cout << std::fixed << std::setprecision(1)
                      << IntMonthToString(month) << ": Average: "
                      << avg << " degrees C, Stdev: " << sstd << std::endl;
        }

    }

    if (!dataFound)
    {
        std::cout << "No Data" << std::endl;
    }

}



// option 3
void Statistics::CalculateAndPrintCorrelationCoefficients(const std::map<int, std::map<int, Bst<WeatherRecordsType>>>& yearMonthData, int month)
{

    // store wind speed, temperature, and solar radiation data
    // extracted from the BST during traversal.
    Vector<float> Speed;
    Vector<float> temp;
    Vector<float> solarRadiations;

    for(auto it = yearMonthData.begin(); it != yearMonthData.end(); ++it)
    {
        int year = it->first;
        const std::map<int, Bst<WeatherRecordsType>>& yearData = it->second;

        if(yearData.find(month) != yearData.end())
        {
            const Bst<WeatherRecordsType>& monthData = yearData.at(month);

            speedPtr = &Speed;
            tempPtr = &temp;
            solarPtr = &solarRadiations;

            monthData.inOrderTraversal(ProcessWindSpeed);
            monthData.inOrderTraversal(ProcessTemperature);
            monthData.inOrderTraversal(ProcessSolarRadiation);

            speedPtr = nullptr;
            tempPtr = nullptr;
            solarPtr = nullptr;
        }
    }

    if (Speed.GetSize() == 0 || temp.GetSize() == 0 || solarRadiations.GetSize() == 0)
    {
        std::cout << "No data available for " << IntMonthToString(month) << std::endl;
        return;
    }

    float s_t = sPCC(Speed, temp);
    float s_r = sPCC(Speed, solarRadiations);
    float t_r = sPCC(temp, solarRadiations);

    std::cout << "\nSample Pearson Correlation Coefficient for " << IntMonthToString(month) << std::endl;
    std::cout << "S_T: " << std::fixed << std::setprecision(2) << s_t << std::endl;
    std::cout << "S_R: " << std::fixed << std::setprecision(2) << s_r << std::endl;
    std::cout << "T_R: " << std::fixed << std::setprecision(2) << t_r << std::endl;
    std::cout << "\n";
}


// option 4
void Statistics::CalculateAndGenerateWindTempSolarReport(const std::map<int, std::map<int, Bst<WeatherRecordsType>>>& yearMonthData, int year)
{
    // opens an output file named WindTempSolar
    std::ofstream outputFile("WindTempSolar.csv");
    outputFile << year << std::endl;

    if (yearMonthData.find(year) == yearMonthData.end())
    {
        outputFile << "No Data" << std::endl;
        return;
    }

    // get data for specified year
    const std::map<int, Bst<WeatherRecordsType>>& yearData = yearMonthData.at(year);

    bool hasData = false; //initializes a flag to track if any data was found

    for (int month = 1; month <= 12; ++month)
    {
        Vector<float> Speed;
        Vector<float> temp;
        Vector<float> solarRadiations;

        if (yearData.find(month) != yearData.end())
        {
            const Bst<WeatherRecordsType>& monthData = yearData.at(month);

            speedPtr = &Speed;
            tempPtr = &temp;
            solarPtr = &solarRadiations;

            // Traverse the BST in-order to get the sorted data
            //  and process wind speed, temperature, and solar radiation
            monthData.inOrderTraversal(ProcessWindSpeed);
            monthData.inOrderTraversal(ProcessTemperature);
            monthData.inOrderTraversal(ProcessSolarRadiation);

            speedPtr = nullptr;
            tempPtr = nullptr;
            solarPtr = nullptr;
        }

        if (Speed.GetSize() == 0 && temp.GetSize() == 0 && solarRadiations.GetSize() == 0)
        {
            continue;
        }

        // if data was found it then calculates
        hasData = true;

        // calculate the statistics
        float averageWindSpeed;
        float stdDevWindSpeed;
        float windMad;
        if (Speed.GetSize() > 0)
        {
            averageWindSpeed = CalculateAvg(Speed);
            stdDevWindSpeed = CalculateStandardDeviation(Speed, averageWindSpeed);
            windMad = mad(Speed);
        }
        else
        {
            averageWindSpeed = 0.0f;
            stdDevWindSpeed = 0.0f;
            windMad = 0.0f;
        }

        float averageTemperature;
        float stdDevTemperature;
        float tempMad;
        if (temp.GetSize() > 0)
        {
            averageTemperature = CalculateAvg(temp);
            stdDevTemperature = CalculateStandardDeviation(temp, averageTemperature);
            tempMad = mad(temp);
        }
        else
        {
            averageTemperature = 0.0f;
            stdDevTemperature = 0.0f;
            tempMad = 0.0f;
        }

        float totalSolarRadiation;
        if (solarRadiations.GetSize() > 0)
        {
            totalSolarRadiation = CalculateTotal(solarRadiations);
        }
        else
        {
            totalSolarRadiation = 0.0f;
        }

        // writes to a csv file
        outputFile << std::fixed << std::setprecision(1)
                   << IntMonthToString(month) << ","
                   << averageWindSpeed << "(" << stdDevWindSpeed << "," << windMad << "),"
                   << averageTemperature << "(" << stdDevTemperature << "," << tempMad << "),"
                   << totalSolarRadiation << std::endl;
    }

    if (!hasData)
    {
        outputFile << "No Data" << std::endl;
    }
}
