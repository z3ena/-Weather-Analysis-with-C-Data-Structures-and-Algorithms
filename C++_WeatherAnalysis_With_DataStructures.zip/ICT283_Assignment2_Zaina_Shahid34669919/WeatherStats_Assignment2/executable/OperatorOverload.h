/**
 * @file DateTimeIO.h.
 * @author Zaina Shahid
 * student id : 34669919
 * @brief  handle all I/O operations for Date and Time objects and Overloaded Comparison operators.
 */

#ifndef OPERATOR_OVERLOAD_H  // Include guard to prevent multiple inclusions
#define OPERATOR_OVERLOAD_H


#include "Weather.h"
#include <iostream>
#include <string>




          /**
           * @brief Converts a Time object to a formatted string "HH:MM".
           *
           * @param time The Time object to be formatted.
           * @return The formatted string representing the time.
           */
std::string TimeFormat(const Time& time);



          /**
           * @brief Converts a Date object to a formatted string "DD/MM/YYYY".
           *
           * @param date The Date object to be formatted.
           * @return The formatted string representing the date.
           */
std::string FullDateFormat(const Date& date);




//-----------------------------------
// Overloaded Operators for Date
//-----------------------------------

          /**
           * @brief Overloaded input stream operator for Date class
           *
           * Reads a date from the input stream in the format specified by the Date class.
           *
           * @param input The input stream to read from
           * @param D The Date object to store the read date
           * @return Reference to the input stream
           */

std::istream& operator>>(std::istream& input, Date& D);


          /**
           * @brief Overloaded output stream operator for Date class
           *
           * Writes a date to the output stream in the format specified by the Date class.
           *
           * @param os The output stream to write to
           * @param D The Date object to be written
           * @return Reference to the output stream
           */
std::ostream& operator<<(std::ostream& os, const Date& D);



          /**
           * @brief Overloaded less than operator.
           * @param lhs The Date object on the left side of the operator.
           * @param rhs The Date object on the right side of the operator.
           * @return true if lhs is earlier than rhs, false otherwise.
           */
bool operator<(const Date& lhs, const Date& rhs);



          /**
           * @brief Overloaded greater than operator.
           * @param lhs The Date object on the left side of the operator.
           * @param rhs The Date object on the right side of the operator.
           * @return true if lhs is later than rhs, false otherwise.
           */
bool operator>(const Date& lhs, const Date& rhs);




          /**
           * @brief Overloaded equality operator.
           * @param lhs The Date object on the left side of the operator.
           * @param rhs The Date object on the right side of the operator.
           * @return true if lhs is equal to rhs, false otherwise.
           */
bool operator==(const Date& lhs, const Date& rhs);




          /**
           * @brief Overloaded inequality operator.
           * @param lhs The Date object on the left side of the operator.
           * @param rhs The Date object on the right side of the operator.
           * @return true if lhs is not equal to rhs, false otherwise.
           */
bool operator!=(const Date& lhs, const Date& rhs);



//-----------------------------------
// Overloaded Operators for Time
//-----------------------------------

            /**
             * @brief Overloaded input stream operator for Time class
             *
             * Reads a time from the input stream in the format specified by the Time class.
             *
             * @param input The input stream to read from
             * @param T The Time object to store the read time
             * @return Reference to the input stream
             */

std::istream& operator>>(std::istream& input, Time& T);


            /**
             * @brief Overloaded output stream operator for Time class
             *
             * Writes a time to the output stream in the format specified by the Time class.
             *
             * @param os The output stream to write to
             * @param T The Time object to be written
             * @return Reference to the output stream
             */
std::ostream& operator<<(std::ostream& os, const Time& T);




           /**
            * @brief Less-than operator for Time comparison.
            *
            * @param lhs The left-hand side Time.
            * @param rhs The right-hand side Time.
            * @return true if lhs is less than rhs, false otherwise.
            */
bool operator<(const Time& lhs, const Time& rhs);



           /**
            * @brief Greater-than operator for Time comparison.
            *
            * @param lhs The left-hand side Time.
            * @param rhs The right-hand side Time.
            * @return true if lhs is greater than rhs, false otherwise.
            */
bool operator>(const Time& lhs, const Time& rhs);



           /**
            * @brief Equality operator for Time comparison.
            *
            * @param lhs The left-hand side Time.
            * @param rhs The right-hand side Time.
            * @return true if lhs is equal to rhs, false otherwise.
            */
bool operator==(const Time& lhs, const Time& rhs);




           /**
            * @brief Inequality operator for Time comparison.
            *
            * @param lhs The left-hand side Time.
            * @param rhs The right-hand side Time.
            * @return true if lhs is not equal to rhs, false otherwise.
            */
bool operator!=(const Time& lhs, const Time& rhs);



//-----------------------------------
// Overloaded Operators for Weather
//-----------------------------------

           /**
            * @brief Less-than operator for WeatherRecordsType comparison.
            *
            * @param lhs The left-hand side WeatherRecordsType.
            * @param rhs The right-hand side WeatherRecordsType.
            * @return true if lhs is less than rhs, false otherwise.
            */
bool operator<(const WeatherRecordsType& lhs, const WeatherRecordsType& rhs);



           /**
            * @brief Greater-than operator for WeatherRecordsType comparison.
            *
            * @param lhs The left-hand side WeatherRecordsType.
            * @param rhs The right-hand side WeatherRecordsType.
            * @return true if lhs is greater than rhs, false otherwise.
            */
bool operator>(const WeatherRecordsType& lhs, const WeatherRecordsType& rhs);





           /**
            * @brief Equality operator for WeatherRecordsType comparison.
            *
            * @param lhs The left-hand side WeatherRecordsType.
            * @param rhs The right-hand side WeatherRecordsType.
            * @return true if lhs is equal to rhs, false otherwise.
            */
bool operator==(const WeatherRecordsType& lhs, const WeatherRecordsType& rhs);





           /**
            * @brief Inequality operator for WeatherRecordsType comparison.
            *
            * @param lhs The left-hand side WeatherRecordsType.
            * @param rhs The right-hand side WeatherRecordsType.
            * @return true if lhs is not equal to rhs, false otherwise.
            */
bool operator!=(const WeatherRecordsType& lhs, const WeatherRecordsType& rhs);



#endif
