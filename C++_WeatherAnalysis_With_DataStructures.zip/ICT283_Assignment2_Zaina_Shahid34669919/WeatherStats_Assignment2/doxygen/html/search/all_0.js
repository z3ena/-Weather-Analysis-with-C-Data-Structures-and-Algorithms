var searchData=
[
  ['amb_5ftemp_0',['amb_temp',['../struct_weather_records_type.html#a40f19a3b8699f497e1184040dda404a5',1,'WeatherRecordsType']]]
];
