var searchData=
[
  ['t_202',['t',['../struct_weather_records_type.html#aa7141817a4d483451f026d01f785fc0e',1,'WeatherRecordsType']]],
  ['tempptr_203',['tempPtr',['../class_statistics.html#a14acc73f2c33e9cb23f90fb8c7b406fc',1,'Statistics']]]
];
