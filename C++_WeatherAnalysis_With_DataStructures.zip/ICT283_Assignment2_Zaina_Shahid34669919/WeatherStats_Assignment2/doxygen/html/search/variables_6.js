var searchData=
[
  ['solar_5fradiations_199',['solar_radiations',['../struct_weather_records_type.html#a81f722d4230dce5560b008d76510ad2e',1,'WeatherRecordsType']]],
  ['solarptr_200',['solarPtr',['../class_statistics.html#afbd6bb1d0ddfd372564226902da3ecec',1,'Statistics']]],
  ['speedptr_201',['speedPtr',['../class_statistics.html#aa9f02fc5bb6bce3cb575595728b27eca',1,'Statistics']]]
];
