var searchData=
[
  ['readdata_172',['readData',['../main_8cpp.html#a0119992cb7264f4bcd418f45993ed390',1,'main.cpp']]],
  ['remove_173',['Remove',['../class_vector.html#a69519d7fb661cf2114ffd3d3c15b99a5',1,'Vector']]]
];
