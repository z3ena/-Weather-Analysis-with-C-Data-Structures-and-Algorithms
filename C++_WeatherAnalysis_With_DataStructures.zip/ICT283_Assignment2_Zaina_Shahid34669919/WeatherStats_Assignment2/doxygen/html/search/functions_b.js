var searchData=
[
  ['time_182',['Time',['../class_time.html#a4245e409c7347d1d671858962c2ca3b5',1,'Time::Time()'],['../class_time.html#ab2532ffd4eacc458882152d920a532ca',1,'Time::Time(unsigned h, unsigned m)']]],
  ['timeformat_183',['TimeFormat',['../_operator_overload_8h.html#aab14ad0bda53222ea9e8f723dbb8f3c8',1,'TimeFormat(const Time &amp;time):&#160;OperatorOverload.cpp'],['../_operator_overload_8cpp.html#aab14ad0bda53222ea9e8f723dbb8f3c8',1,'TimeFormat(const Time &amp;time):&#160;OperatorOverload.cpp']]]
];
