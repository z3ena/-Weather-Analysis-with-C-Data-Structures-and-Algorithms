var struct_weather_records_type =
[
    [ "amb_temp", "struct_weather_records_type.html#a40f19a3b8699f497e1184040dda404a5", null ],
    [ "d", "struct_weather_records_type.html#a4e8428ac2e96b56efd39c2a53a21f80b", null ],
    [ "solar_radiations", "struct_weather_records_type.html#a81f722d4230dce5560b008d76510ad2e", null ],
    [ "t", "struct_weather_records_type.html#aa7141817a4d483451f026d01f785fc0e", null ],
    [ "wind_speed", "struct_weather_records_type.html#a16ac6ad05225d5525af31b2582f1d7f5", null ]
];