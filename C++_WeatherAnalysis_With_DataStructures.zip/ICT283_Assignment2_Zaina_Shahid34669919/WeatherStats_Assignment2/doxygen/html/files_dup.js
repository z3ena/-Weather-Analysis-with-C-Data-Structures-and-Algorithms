var files_dup =
[
    [ "Bst.h", "_bst_8h.html", [
      [ "BstNode", "struct_bst_node.html", "struct_bst_node" ],
      [ "Bst", "class_bst.html", "class_bst" ]
    ] ],
    [ "Date.cpp", "_date_8cpp.html", null ],
    [ "Date.h", "_date_8h.html", [
      [ "Date", "class_date.html", "class_date" ]
    ] ],
    [ "main.cpp", "main_8cpp.html", "main_8cpp" ],
    [ "Map.h", "_map_8h.html", null ],
    [ "OperatorOverload.cpp", "_operator_overload_8cpp.html", "_operator_overload_8cpp" ],
    [ "OperatorOverload.h", "_operator_overload_8h.html", "_operator_overload_8h" ],
    [ "Statistics.cpp", "_statistics_8cpp.html", null ],
    [ "Statistics.h", "_statistics_8h.html", [
      [ "Statistics", "class_statistics.html", "class_statistics" ]
    ] ],
    [ "Time.cpp", "_time_8cpp.html", null ],
    [ "Time.h", "_time_8h.html", [
      [ "Time", "class_time.html", "class_time" ]
    ] ],
    [ "Vector.h", "_vector_8h.html", [
      [ "Vector", "class_vector.html", "class_vector" ]
    ] ],
    [ "Weather.h", "_weather_8h.html", "_weather_8h" ]
];