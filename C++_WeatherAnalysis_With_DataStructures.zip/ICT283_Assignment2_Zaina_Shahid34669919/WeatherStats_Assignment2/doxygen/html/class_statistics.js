var class_statistics =
[
    [ "CalculateAndGenerateWindTempSolarReport", "class_statistics.html#a22978f4c61bd2050cf99b52560e4133c", null ],
    [ "CalculateAndPrintAverageAmbientAirTemperatureAndStdDev", "class_statistics.html#ae3770b73acd6c7dffe7efd88e0128c2e", null ],
    [ "CalculateAndPrintAverageWindSpeedAndStdDev", "class_statistics.html#aa1859dfb8cf6a23a866d3950c6b5a99c", null ],
    [ "CalculateAndPrintCorrelationCoefficients", "class_statistics.html#a475b82d7279059a557631654cc032e45", null ],
    [ "CalculateAvg", "class_statistics.html#aef68362695a9dcc0dca5ba152add39c6", null ],
    [ "CalculateStandardDeviation", "class_statistics.html#a74ce3345112bcb4094ef62b785e02419", null ],
    [ "CalculateTotal", "class_statistics.html#a6f766bc23ffb0768665141b8e6154d98", null ],
    [ "ConvertSolarRadiationFromWtoKWH", "class_statistics.html#a67a97b165b19c30580010c846bca1172", null ],
    [ "ConvertWindSpeedFromMStoKMH", "class_statistics.html#ab841d7f7fcf1b6387ff7df4841ac3d8d", null ],
    [ "IntMonthToString", "class_statistics.html#af33c0f3088139dba31f582bb1ea8887f", null ],
    [ "mad", "class_statistics.html#ac2f495663de9426078b7e4836d4c0a8e", null ],
    [ "ProcessData", "class_statistics.html#af6415cf91418c684e23457a2eb5516b9", null ],
    [ "ProcessSolarRadiation", "class_statistics.html#aab6c39cbddefe62ffe94f1964ab9638d", null ],
    [ "ProcessTemperature", "class_statistics.html#ac0306764837f1cabac68e6d5db7d6a30", null ],
    [ "ProcessWindSpeed", "class_statistics.html#adf41c7945dc532c811c6a498cdaf0544", null ],
    [ "sPCC", "class_statistics.html#aa1ae25b6c4ff6d6d01e5bc2639e98f3b", null ],
    [ "solarPtr", "class_statistics.html#afbd6bb1d0ddfd372564226902da3ecec", null ],
    [ "speedPtr", "class_statistics.html#aa9f02fc5bb6bce3cb575595728b27eca", null ],
    [ "tempPtr", "class_statistics.html#a14acc73f2c33e9cb23f90fb8c7b406fc", null ]
];