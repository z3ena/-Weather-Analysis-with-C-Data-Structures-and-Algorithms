var class_time =
[
    [ "Time", "class_time.html#a4245e409c7347d1d671858962c2ca3b5", null ],
    [ "Time", "class_time.html#ab2532ffd4eacc458882152d920a532ca", null ],
    [ "GetHour", "class_time.html#aaf65e0dc73514ffab9b3dd643cef9bdb", null ],
    [ "GetMinute", "class_time.html#a86302564cc0783b402dc5f0e137a43c1", null ],
    [ "SetHour", "class_time.html#a4be6aa42ad0134696e196790daf901c6", null ],
    [ "SetMinute", "class_time.html#adf222f59b771dd26070379fefe651f62", null ],
    [ "hour", "class_time.html#a497d35aa44ea40706dbab08f7a31d069", null ],
    [ "mins", "class_time.html#a8e756f2ba52928b16d0927fd8dc0300b", null ]
];