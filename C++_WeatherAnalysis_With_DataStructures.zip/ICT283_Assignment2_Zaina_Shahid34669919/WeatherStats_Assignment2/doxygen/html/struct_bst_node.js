var struct_bst_node =
[
    [ "BstNode", "struct_bst_node.html#a8c0e28161326678638103fe23c22c3a7", null ],
    [ "data", "struct_bst_node.html#a8b70ee0f36edb50a349edc0e2e790ddd", null ],
    [ "leftL", "struct_bst_node.html#a316702953c61fe7c7a6ab2e67751e9dd", null ],
    [ "rightL", "struct_bst_node.html#a79fde2335ba2b763062049ecde9c38ae", null ]
];