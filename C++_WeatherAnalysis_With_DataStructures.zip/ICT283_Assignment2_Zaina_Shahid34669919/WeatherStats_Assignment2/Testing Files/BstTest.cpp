// UNIT TESTING FOR BST.H

#include <iostream>
#include "Bst.h"

// Test functions

void test1()
{
    Bst<int> bst;

    bst.Insert_B(10);
    bst.Insert_B(5);
    bst.Insert_B(15);

    bool result1 = bst.Search(10);
    bool result2 = bst.Search(5);
    bool result3 = bst.Search(15);
    bool result4 = bst.Search(20);

    std::cout << "test1 - Search 10: ";
    if (result1) {
        std::cout << "Passed" << std::endl;
    } else {
        std::cout << "Failed" << std::endl;
    }

    std::cout << "test1 - Search 5: ";
    if (result2) {
        std::cout << "Passed" << std::endl;
    } else {
        std::cout << "Failed" << std::endl;
    }

    std::cout << "test1 - Search 15: ";
    if (result3) {
        std::cout << "Passed" << std::endl;
    } else {
        std::cout << "Failed" << std::endl;
    }

    std::cout << "test1 - Search 20: ";
    if (!result4) {
        std::cout << "Passed" << std::endl;
    } else {
        std::cout << "Failed" << std::endl;
    }
}

void test2()
 {
    Bst<int> bst;

    bst.Insert_B(10);
    bst.Insert_B(5);
    bst.Insert_B(15);

    std::cout << "test2 - In-order traversal: ";
    bst.inOrderTraversal([](const int& data) {
        std::cout << data << " ";
    });
    std::cout << std::endl;
}

void test3()
{
    Bst<int> bst;

    bst.Insert_B(10);
    bst.Insert_B(5);
    bst.Insert_B(15);

    std::cout << "test3 - Pre-order traversal: ";
    bst.preOrderTraversal([](int &data) {
        std::cout << data << " ";
    });
    std::cout << std::endl;
}

void test4()
 {
    Bst<int> bst;

    bst.Insert_B(10);
    bst.Insert_B(5);
    bst.Insert_B(15);

    std::cout << "test4 - Post-order traversal: ";
    bst.postOrderTraversal([](int &data) {
        std::cout << data << " ";
    });
    std::cout << std::endl;
}

void test5()
{
    Bst<int> bst;

    bst.Insert_B(10);
    bst.Insert_B(5);
    bst.Insert_B(15);

    bst.DeleteTree();

    bool result1 = !bst.Search(10);
    bool result2 = !bst.Search(5);
    bool result3 = !bst.Search(15);

    std::cout << "test5 - Search 10 after delete: ";
    if (result1) {
        std::cout << "Passed" << std::endl;
    } else {
        std::cout << "Failed" << std::endl;
    }

    std::cout << "test5 - Search 5 after delete: ";
    if (result2) {
        std::cout << "Failed" << std::endl;
    } else {
        std::cout << "Passed" << std::endl;
    }

    std::cout << "test5 - Search 15 after delete: ";
    if (result3) {
        std::cout << "Failed" << std::endl;
    } else {
        std::cout << "Passed" << std::endl;
    }
}

// Main function to call all test functions
int main() {
    test1();
    test2();
    test3();
    test4();
    test5();


    return 0;
}
