// UNIT TESTING FOR VECTOR.H

#include <iostream>
#include <stdexcept>
#include "Vector.h"

// Helper function to print results
void printResult(const std::string& testName, bool result)
{
    std::cout << testName << ": ";
    if (result) {
        std::cout << "Passed" << std::endl;
    } else {
        std::cout << "Failed" << std::endl;
    }
}

// Test functions
void test1()
{
    Vector<int> vec;
    bool result = (vec.GetSize() == 0 && vec.GetCapacity() > 0);
    printResult("test1 - Initial size and capacity", result);
}

void test2()
{
    Vector<int> vec;
    vec.Insert(10);
    vec.Insert(20);
    vec.Insert(30);

    bool result = (vec.GetSize() == 3 && vec.GetCapacity() >= 3);
    printResult("test2 - Insert and size/capacity", result);
}

void test3()
{
    Vector<int> vec;
    vec.Insert(10);
    vec.Insert(20);

    bool result = (vec[0] == 10 && vec[1] == 20);
    printResult("test3 - Access elements", result);
}

void test4() {
    Vector<int> vec;
    vec.Insert(10);
    vec.Insert(20);
    vec.Remove();

    bool result = (vec.GetSize() == 1 && vec[0] == 10);
    printResult("test4 - Remove last element", result);
}

void test5()
{
    Vector<int> vec;
    vec.Insert(10);
    vec.Insert(20);
    vec.Remove();
    vec.Remove();

    bool result = (vec.GetSize() == 0 && !vec.Remove()); // Remove should fail now
    printResult("test5 - Remove when empty", result);
}

void test6()
{
    Vector<int> vec1;
    vec1.Insert(10);
    vec1.Insert(20);

    Vector<int> vec2(vec1); // Test copy constructor
    bool result = (vec2.GetSize() == 2 && vec2[0] == 10 && vec2[1] == 20);
    printResult("test6 - Copy constructor", result);
}

void test7()
{
    Vector<int> vec1;
    vec1.Insert(10);
    vec1.Insert(20);

    Vector<int> vec2;
    vec2 = vec1; // Test assignment operator

    bool result = (vec2.GetSize() == 2 && vec2[0] == 10 && vec2[1] == 20);
    printResult("test7 - Assignment operator", result);
}

void test8()
{
    Vector<int> vec;
    vec.Insert(10);
    vec.Insert(20);

    try {
        vec[2] = 30; // Access out of bounds
        std::cout << "test8 - Out of bounds access: Failed" << std::endl;
    } catch (const std::out_of_range&) {
        std::cout << "test8 - Out of bounds access: Passed" << std::endl;
    }
}

// Main function to call all test functions
int main() {
    test1();
    test2();
    test3();
    test4();
    test5();
    test6();
    test7();
    test8();

    return 0;
}

