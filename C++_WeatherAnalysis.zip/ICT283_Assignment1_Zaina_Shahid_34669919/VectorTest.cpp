/**
 * @file VectorTest.cpp
 * @author Zaina Shahid
 * student id : 34669919
 * @brief Unit Testing file for Vector.h
 */



#include "Vector.h"
#include <iostream>

void Test1();  // Default constructor test
void Test2();  // Copy constructor test
void Test3();  // Assignment operator test
void Test4();  // Insert and GetSize test
void Test5();  // Remove test
void Test6(); // Resize test
void Test7();
void Test8();  //[]


int main()
{
    std::cout << "VECTOR TESTING PROGRAM FILE" << std::endl << std::endl;
    Test1();
    Test2();
    Test3();
    Test4();
    Test5();
    Test6();
    Test7();
    Test8();

    std::cout << std::endl;
    return 0;
}

void Test1()
{
    Vector<int> v1;
    std::cout << "T1 : Default Constructor" << std::endl;
    std::cout << "Size: " << v1.GetSize() << ", Capacity: " << v1.GetCapacity() << std::endl;
}

void Test2()
{
    Vector<int> v1;
    int arr[] = {1, 2, 3, 4, 5};
    for (int i = 0; i < 5; i++)
    {
        v1.Insert(arr[i]);
    }

    std::cout << "T2 : Copy Constructor" << std::endl;
    Vector<int> v2(v1);
    std::cout << "Size: " << v2.GetSize() << ", Capacity: " << v2.GetCapacity() << std::endl;
}

void Test3()
{
    Vector<int> v1, v2;
    int arr[] = {1, 2, 3, 4, 5};
    for (int i = 0; i < 5; i++)
    {
        v1.Insert(arr[i]);
    }

    std::cout << "T3 : Assignment Operator" << std::endl;
    v2 = v1;
    std::cout << "Size: " << v2.GetSize() << ", Capacity: " << v2.GetCapacity() << std::endl;
}

void Test4()
{
    Vector<int> v1;
    int arr[] = {10, 20, 31, 42, 50};

    std::cout << "T4 : Insert and GetSize" << std::endl;
    for (int i = 0; i < 5; i++)
    {
        v1.Insert(arr[i]);
        std::cout << "Inserted " << arr[i] << ", Size: " << v1.GetSize() << std::endl;
    }
}

void Test5()
 {
    Vector<int> v1;
    int arr[] = {11, 9, 3, 7, 8};
    for (int i = 0; i < 5; i++)
    {
        v1.Insert(arr[i]);
    }

    std::cout << "T5 : Remove" << std::endl;
    while (v1.GetSize() > 0) {
        std::cout << "Removed element, Size: " << v1.GetSize() << std::endl;
        v1.Remove();
    }
}



void Test6()
{
    Vector<int> v1;
    int arr[] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15};
    for (int i = 0; i < 15; i++)
    {
        v1.Insert(arr[i]);
    }

    std::cout << "T6 : Resize" << std::endl;
    std::cout << "Size: " << v1.GetSize() << ", Capacity: " << v1.GetCapacity() << std::endl;
}


void Test7() {
    Vector<int> v1;
    int arr[] = {10, 20, 30, 40, 50};
    for (int i = 0; i < 5; i++)
    {
        v1.Insert(arr[i]);
    }

    std::cout << "T7 : Overloaded [] (non-const)" << std::endl;
    if (v1.GetSize() > 2)
        {
        std::cout << "Element at index 2: " << v1[2] << std::endl;  // Should print 30
        v1[2] = 35;
        std::cout << "Updated element at index 2: " << v1[2] << std::endl;  // Should print 35
    } else
    {
        std::cout<< "Index out of bounds" << std::endl;
    }

    if (v1.GetSize() > 5)
    {
        std::cout << "Accessing out of bounds index: " << v1[5] << std::endl;  // Should print an error message
    } else {
        std::cout << "Index out of bounds" << std::endl;
    }
}

void Test8()
{
    const Vector<int> v1 = []()
    {
        Vector<int> temp;
        int arr[] = {10, 20, 30, 40, 50};
        for (int i = 0; i < 5; i++) {
            temp.Insert(arr[i]);
        }
        return temp;
    }();

    std::cout << "T8 : Overloaded [] (const)" << std::endl;
    if (v1.GetSize() > 2)
    {
        std::cout << "Element at index 2: " << v1[2] << std::endl;  // Should print 30
    } else {
        std::cout << "Index out of bounds" << std::endl;
    }

    if (v1.GetSize() > 5)
    {
        std::cout << "Accessing out of bounds index: " << v1[5] << std::endl;  // Should print an error message
    } else {
        std::cout << "Index out of bounds" << std::endl;
    }
}
