/**
 * @file DateTest.cpp
 * @author Zaina Shahid
 * student id : 34669919
 * @brief Unit Testing file for Date.h
 */


 #include "Date.h"
 #include <iostream>
 using namespace std;

void Test1();  // Default constructor test
void Test2();  // Parameterized constructor test
void Test3();  // Accessors and Mutators test
void Test4();  // FullDateFormat test

int main()
{
    cout << "DATE TESTING PROGRAM FILE" << endl << endl;
    Test1();
    Test2();
    Test3();
    Test4();
    cout << endl;
    return 0;
}

void Test1()
{
    Date d1;
    cout << "T1: Default Constructor" <<endl;
    cout << "Expected: 0/0/0" << endl;
    cout << "Actual: " << d1.FullDateFormat() <<endl<<endl;
}

void Test2()
{
    Date d2(15, 6, 2024);
    cout << "T2: Parameterized Constructor" <<endl;
    cout << "Expected: 15/6/2024" <<endl;
    cout << "Actual: " << d2.FullDateFormat() <<endl << endl;
}

void Test3()
{
    Date d3;
    d3.SetDay(10);
    d3.SetMonth(12);
    d3.SetYear(2023);
    cout << "T3: Accessors and Mutators" <<endl;
    cout << "Expected: 10/12/2023" <<endl;
    cout << "Actual: " << d3.FullDateFormat() <<endl;
    cout << "Get Day: " << d3.GetDay() << " (Expected: 10)" <<endl;
    cout << "Get Month: " << d3.GetMonth() << " (Expected: 12)" <<endl;
    cout << "Get Year: " << d3.GetYear() << " (Expected: 2023)" <<endl <<endl;
}

void Test4()
{
    Date d4(1, 1, 2000);
   cout << "T4: FullDateFormat" << endl;
   cout << "Expected: 1/1/2000" << endl;
   cout << "Actual: " << d4.FullDateFormat() <<endl <<endl;
}

