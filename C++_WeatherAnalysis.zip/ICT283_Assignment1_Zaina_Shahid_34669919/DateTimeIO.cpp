/// Author : Zaina Shahid
/// Student ID : 34669919
/// File : Implementation File DateTimeIO.cpp

#include "DateTimeIO.h"


// Date.h

// Overloaded extraction operator for reading a Date object from input stream
std::istream& operator>>(std::istream& input, Date& D)
 {
    std::string dStr, mStr, yStr;
    unsigned dInt, mInt, yInt;  //store the converted numeric values

    getline(input, dStr, '/');  // using getline to read characters until it encounter '/'
    dInt = std::stoi(dStr);  // stores this substring in Dstr and converts it to an int using stoi and stores it in dInt
    D.SetDay(dInt);  //using the set method

    getline(input, mStr, '/');
    mInt = std::stoi(mStr);       //similarly
    D.SetMonth(mInt);

    getline(input, yStr, ' ');   // reads until a space character (or end of line)
    yInt = std::stoi(yStr);
    D.SetYear(yInt);

    return input;
}

// Overloaded insertion operator for writing a Date object to an output stream
std::ostream& operator<<(std::ostream& os, const Date& D)
{
    os << D.FullDateFormat();
    return os;
}


// Date.cpp


// Overloaded extraction operator for reading a Time object from input stream
std::istream& operator>>(std::istream& input, Time& T)
{
    std::string hourStr, minuteStr;
    unsigned hourInt, minuteInt;

    getline(input, hourStr, ':');
    hourInt = std::stoi(hourStr);
    T.SetHour(hourInt);

    getline(input, minuteStr, ',');
    minuteInt = std::stoi(minuteStr);
    T.SetMinute(minuteInt);

    return input;
}

// Overloaded insertion operator for writing a Time object to an output stream
std::ostream& operator<<(std::ostream& os, const Time& T)
 {
    os << T.TIME_24Format();
    return os;
}
