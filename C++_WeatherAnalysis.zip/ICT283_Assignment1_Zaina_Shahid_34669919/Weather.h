/**
 * @file Weather.h
 * @author Zaina Shahid
 * student id : 34669919
 * @brief Defines structures and types for weather data storage and management
 */


#ifndef WEATHER_H
#define WEATHER_H


#include "Date.h"
#include "Time.h"
#include "Vector.h"



     /**
      * @struct WeatherRecordsType
      * @brief Represents a single weather record with date, time, and various measurements
      */
typedef struct
{
    Date d;
    Time t;
    float wind_speed;
    int solar_radiations;
    float amb_temp;

} WeatherRecordsType;


    /**
     * @typedef WeatherLogType
     * @brief Represents a collection of weather records using the Vector class
     */
typedef Vector<WeatherRecordsType> WeatherLogType;

//WeatherLogType is a type alias. It is defined as a Vector of WeatherRecordsType

#endif // WEATHER_H
