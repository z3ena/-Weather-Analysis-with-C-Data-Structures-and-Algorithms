/**
 * @file TimeTest.cpp
 * @author Zaina Shahid
 * student id : 34669919
 * @brief Unit Testing file for Time.h
 */

#include "Time.h"
#include <iostream>

using namespace std;

void Test1(); // Default constructor test
void Test2(); // Parameterized constructor test
void Test3(); // Accessor and Mutator methods test
void Test4(); // Time format test

int main()
 {
    cout << "TIME TESTING PROGRAM FILE" << endl << endl;
    Test1();
    Test2();
    Test3();
    Test4();
    cout << endl;
    return 0;
}

void Test1()
{
    Time t1;
    cout << "T1 : Default Constructor" << endl;
    cout << "Hour: " << t1.GetHour() << ", Minute: " << t1.GetMinute() << endl;
    cout << "Default constructor works correctly!" << endl;
}

void Test2()
{
    Time t2(10, 30);
    cout << "T2 : Parameterized Constructor" << endl;
    cout << "Hour: " << t2.GetHour() << ", Minute: " << t2.GetMinute() << endl;
    cout << "Parameterized constructor works correctly!" << endl;
}

void Test3()
{
    Time t3;
    t3.SetHour(5);
    t3.SetMinute(45);
    cout << "T3 : Accessor and Mutator Methods" << endl;
    cout << "Hour: " << t3.GetHour() << ", Minute: " << t3.GetMinute() << endl;
    cout << "Accessor and mutator methods work correctly!" << endl;
}

void Test4()
{
    Time t4(15, 20);
    cout << "T4 : Time Format Test" << endl;
    cout << "Time in 24-hour format: " << t4.TIME_24Format() << endl;
    cout << "Time format method works correctly!" << endl;
}
