/// Author : Zaina Shahid
/// Student ID : 34669919
/// File : Implementation File Statistics.cpp

#include "Statistics.h"
#include <iostream>
#include <fstream>
#include <iomanip>
#include <cmath>

//calculating the total sum of a Vector of float values
float Statistics::CalculateTotal(const Vector<float>& values)
{
    float sum = 0.0f;
    for (int i = 0; i < values.GetSize(); ++i)
    {
        sum += values[i];
    }
    return sum;
}

//calculating the average
float Statistics::CalculateAvg(const Vector<float>& values)
{

    float total = CalculateTotal(values);
    return total / values.GetSize();

}

//calculating the standard deviation
float Statistics::CalculateStandardDeviation(const Vector<float>& values, float average)
{
    float sum = 0.0f;
    for (int i = 0; i < values.GetSize(); ++i)
    {
        sum += pow(values[i] - average, 2);
    }
    return sqrt(sum / values.GetSize());

}

//converts wind speed from meters per second to kilometers
float Statistics::ConvertWindSpeedFromMStoKMH(float windSpeed)
{
    return windSpeed * 3.6f;
}

//converts solar radiation from watts to kilowatt-hours per square meter
float Statistics::ConvertSolarRadiationFromWtoKWH(float solarRadiation)
{
    return solarRadiation * 1.0f / 6.0f / 1000.0f;
}

//converts an integer month to its string representation
std::string Statistics::IntMonthToString(const int &month)
{
    switch (month)
    {
    case 1: return "January";
    case 2: return "February";
    case 3: return "March";
    case 4: return "April";
    case 5: return "May";
    case 6: return "June";
    case 7: return "July";
    case 8: return "August";
    case 9: return "September";
    case 10: return "October";
    case 11: return "November";
    case 12: return "December";
    default:
        std::cout << std::endl << "Error converting int month to string" << std::endl;
    }
}


void Statistics::CalculateAndPrintAverageWindSpeedAndStdDev(const WeatherLogType& weatherData, int year, int month)
{
    // a Vector to store the wind speeds
    Vector<float> Speed;
    for(int i = 0; i < weatherData.GetSize(); ++i)
    {

        if(weatherData[i].d.GetYear() == year && weatherData[i].d.GetMonth() == month)
        {
            float s = ConvertWindSpeedFromMStoKMH(weatherData[i].wind_speed);
            Speed.Insert(s); //adds it to the Vector


        }
    }

    if(Speed.GetSize() == 0)
    {
        std::cout << "No Data for " << month << " " << year << std::endl;
        return;
    }

    float avg = CalculateAvg(Speed);
    float sstd = CalculateStandardDeviation(Speed, avg);

    std::cout << IntMonthToString(month) << " " << year << ":" << std::endl;
    std::cout << "Average speed: " << std::fixed << std::setprecision(1) << avg << " km/h" << std::endl;
    std::cout << "Sample stdev: " << std::fixed << std::setprecision(1) << sstd << std::endl;

}



void Statistics::CalculateAndPrintAverageAmbientAirTemperatureAndStdDev(const WeatherLogType& weatherData, int year)
{
     for (int month = 1; month <= 12; ++month)
    {
        // for each month it creates a Vector to store the temperatures.
        Vector<float> temp;
        for (int i = 0; i < weatherData.GetSize(); ++i)
        {
            if (weatherData[i].d.GetYear() == year && weatherData[i].d.GetMonth() == month)
            {
                float t = weatherData[i].amb_temp;
                temp.Insert(t);  //adds it to the vector
            }
        }
        if (temp.GetSize() == 0) {
            std::cout << month << ": No Data" << std::endl;
            continue;
        }

        float avg = CalculateAvg(temp);
        float sstd = CalculateStandardDeviation(temp, avg);

        std::cout << std::fixed << std::setprecision(1) << IntMonthToString(month) << " : Average :"
                  << avg << " degrees C, Stdev: " << sstd << std::endl;

    }

}


void Statistics::CalculateAndPrintTotalSolarRadiation(const WeatherLogType& weatherData, int year)
{

    for (int month = 1; month <= 12; ++month)
    {
        Vector<float> solarRadiations;
        for (int i = 0; i < weatherData.GetSize(); ++i)
        {
            if (weatherData[i].d.GetYear() == year && weatherData[i].d.GetMonth() == month)
            {
                float sr = ConvertSolarRadiationFromWtoKWH(weatherData[i].solar_radiations);
                solarRadiations.Insert(sr);
            }
        }
        if (solarRadiations.GetSize() == 0)
        {
            std::cout << month << ": No Data" << std::endl;
            continue;
        }
        // calculates total
        float TotalSolarRadiation = CalculateTotal(solarRadiations);
        std::cout << std::fixed << std::setprecision(1) << IntMonthToString(month) << ": "
                  << TotalSolarRadiation << " kWh/m^2" << std::endl;
    }

}


//generates a comprehensive report for wind speed, temperature, and solar radiation for a specified year
void Statistics::CalculateAndGenerateWindTempSolarReport(const WeatherLogType& weatherData, int year)
{
    // opens an output file named WindTempSolar
    std::ofstream outputFile("WindTempSolar.csv");
    outputFile << year << std::endl;
    bool hasData = false;  //initializes a flag to track if any data was found
    for(int month = 1; month <= 12; ++month)
    {
        Vector<float> Speed;
        Vector<float> temp;
        Vector<float> solarRadiations;
        for (int i = 0; i < weatherData.GetSize(); ++i) {
            if (weatherData[i].d.GetYear() == year && weatherData[i].d.GetMonth() == month) {

                float s = ConvertWindSpeedFromMStoKMH(weatherData[i].wind_speed);
                Speed.Insert(s);
                float t = weatherData[i].amb_temp;
                temp.Insert(t);
                float sr = ConvertSolarRadiationFromWtoKWH(weatherData[i].solar_radiations);
                solarRadiations.Insert(sr);
            }
        }
        // if no data was found for the current month it skips to the next month
        if (Speed.GetSize() == 0 && temp.GetSize() == 0 && solarRadiations.GetSize() == 0) {
            continue;
        }

        // if data was found it then calculates
        hasData = true;
        float averageWindSpeed;
        float stdDevWindSpeed;
        if (Speed.GetSize() > 0)
        {
            averageWindSpeed = CalculateAvg(Speed);
            stdDevWindSpeed = CalculateStandardDeviation(Speed, averageWindSpeed);

        } else
        {
            averageWindSpeed = 0.0f;
            stdDevWindSpeed = 0.0f;
        }

        float averageTemperature;
        float stdDevTemperature;

        if (temp.GetSize() > 0)
        {
            averageTemperature = CalculateAvg(temp);
            stdDevTemperature = CalculateStandardDeviation(temp, averageTemperature);

        } else
        {
            averageTemperature = 0.0f;
            stdDevTemperature = 0.0f;
        }

        float totalSolarRadiation;
        if (solarRadiations.GetSize() > 0)
        {
            totalSolarRadiation = CalculateTotal(solarRadiations);

        } else
        {
            totalSolarRadiation = 0.0f;
        }

         // writes to a csv file
        outputFile << std::fixed << std::setprecision(1)<< IntMonthToString(month) << ","
                    << averageWindSpeed << "(" << stdDevWindSpeed << "),"
                    << averageTemperature << "(" << stdDevTemperature << "),"
                    << totalSolarRadiation << std::endl;
    }
    if (!hasData) {
        outputFile << "No Data" << std::endl;
    }




}
