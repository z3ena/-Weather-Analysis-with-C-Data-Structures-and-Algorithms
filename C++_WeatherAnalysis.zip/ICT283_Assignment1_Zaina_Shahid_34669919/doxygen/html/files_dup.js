var files_dup =
[
    [ "Date.cpp", "_date_8cpp.html", null ],
    [ "Date.h", "_date_8h.html", [
      [ "Date", "class_date.html", "class_date" ]
    ] ],
    [ "DateTest.cpp", "_date_test_8cpp.html", "_date_test_8cpp" ],
    [ "DateTimeIO.cpp", "_date_time_i_o_8cpp.html", "_date_time_i_o_8cpp" ],
    [ "DateTimeIO.h", "_date_time_i_o_8h.html", "_date_time_i_o_8h" ],
    [ "main.cpp", "main_8cpp.html", "main_8cpp" ],
    [ "Statistics.cpp", "_statistics_8cpp.html", null ],
    [ "Statistics.h", "_statistics_8h.html", [
      [ "Statistics", "class_statistics.html", "class_statistics" ]
    ] ],
    [ "Time.cpp", "_time_8cpp.html", null ],
    [ "Time.h", "_time_8h.html", [
      [ "Time", "class_time.html", "class_time" ]
    ] ],
    [ "TimeTest.cpp", "_time_test_8cpp.html", "_time_test_8cpp" ],
    [ "Vector.h", "_vector_8h.html", [
      [ "Vector", "class_vector.html", "class_vector" ]
    ] ],
    [ "VectorTest.cpp", "_vector_test_8cpp.html", "_vector_test_8cpp" ],
    [ "Weather.cpp", "_weather_8cpp.html", null ],
    [ "Weather.h", "_weather_8h.html", "_weather_8h" ]
];