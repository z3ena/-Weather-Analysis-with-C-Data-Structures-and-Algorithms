var class_time =
[
    [ "Time", "class_time.html#a4245e409c7347d1d671858962c2ca3b5", null ],
    [ "Time", "class_time.html#ae8f940eac879a9c1018bf8e48bb514aa", null ],
    [ "~Time", "class_time.html#a1e92dbe963fa3cdd6bea207680f5f6d1", null ],
    [ "GetHour", "class_time.html#aaf65e0dc73514ffab9b3dd643cef9bdb", null ],
    [ "GetMinute", "class_time.html#a86302564cc0783b402dc5f0e137a43c1", null ],
    [ "SetHour", "class_time.html#ace5d3921c2b4619afe38250d78d77536", null ],
    [ "SetMinute", "class_time.html#ac7a88473bf7849235b915216a122275b", null ],
    [ "TIME_24Format", "class_time.html#a6257c921dc81a0d7af98de97aba1e5af", null ],
    [ "hour", "class_time.html#a497d35aa44ea40706dbab08f7a31d069", null ],
    [ "mins", "class_time.html#a8e756f2ba52928b16d0927fd8dc0300b", null ]
];