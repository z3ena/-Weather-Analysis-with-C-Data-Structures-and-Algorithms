var searchData=
[
  ['readdata_131',['readData',['../main_8cpp.html#a0119992cb7264f4bcd418f45993ed390',1,'main.cpp']]],
  ['remove_132',['Remove',['../class_vector.html#a69519d7fb661cf2114ffd3d3c15b99a5',1,'Vector']]],
  ['resize_133',['Resize',['../class_vector.html#a48ff77e985a2e61341410b193396305f',1,'Vector']]]
];
