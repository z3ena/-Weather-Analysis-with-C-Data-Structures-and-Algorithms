var searchData=
[
  ['weatherrecordstype_87',['WeatherRecordsType',['../struct_weather_records_type.html',1,'']]]
];
