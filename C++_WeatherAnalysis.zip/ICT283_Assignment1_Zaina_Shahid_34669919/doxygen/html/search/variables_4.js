var searchData=
[
  ['solar_5fradiations_164',['solar_radiations',['../struct_weather_records_type.html#a81f722d4230dce5560b008d76510ad2e',1,'WeatherRecordsType']]]
];
