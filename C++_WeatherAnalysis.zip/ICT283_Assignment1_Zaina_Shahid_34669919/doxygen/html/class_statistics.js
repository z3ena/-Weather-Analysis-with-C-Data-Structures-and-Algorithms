var class_statistics =
[
    [ "CalculateAndGenerateWindTempSolarReport", "class_statistics.html#a2221caa274521bc4b0acff5d7bb945da", null ],
    [ "CalculateAndPrintAverageAmbientAirTemperatureAndStdDev", "class_statistics.html#ae3b7df581f95f4d6ce605e5654bec054", null ],
    [ "CalculateAndPrintAverageWindSpeedAndStdDev", "class_statistics.html#abc94c00c08687f4242e490861be01555", null ],
    [ "CalculateAndPrintTotalSolarRadiation", "class_statistics.html#a1efa4ba58744bff3498636dea1ce4d56", null ],
    [ "CalculateAvg", "class_statistics.html#aef68362695a9dcc0dca5ba152add39c6", null ],
    [ "CalculateStandardDeviation", "class_statistics.html#a74ce3345112bcb4094ef62b785e02419", null ],
    [ "CalculateTotal", "class_statistics.html#a6f766bc23ffb0768665141b8e6154d98", null ],
    [ "ConvertSolarRadiationFromWtoKWH", "class_statistics.html#a67a97b165b19c30580010c846bca1172", null ],
    [ "ConvertWindSpeedFromMStoKMH", "class_statistics.html#ab841d7f7fcf1b6387ff7df4841ac3d8d", null ],
    [ "IntMonthToString", "class_statistics.html#af33c0f3088139dba31f582bb1ea8887f", null ]
];