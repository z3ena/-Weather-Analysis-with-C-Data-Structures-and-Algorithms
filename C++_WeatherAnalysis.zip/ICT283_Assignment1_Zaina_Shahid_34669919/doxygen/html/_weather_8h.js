var _weather_8h =
[
    [ "WeatherRecordsType", "struct_weather_records_type.html", "struct_weather_records_type" ],
    [ "WeatherLogType", "_weather_8h.html#adf5bc85854cf77ab519f9d7111ae76ae", null ]
];