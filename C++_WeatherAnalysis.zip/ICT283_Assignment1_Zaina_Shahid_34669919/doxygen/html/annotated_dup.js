var annotated_dup =
[
    [ "Date", "class_date.html", "class_date" ],
    [ "Statistics", "class_statistics.html", "class_statistics" ],
    [ "Time", "class_time.html", "class_time" ],
    [ "Vector", "class_vector.html", "class_vector" ],
    [ "WeatherRecordsType", "struct_weather_records_type.html", "struct_weather_records_type" ]
];