/// ICT283 Data Structures and Abstractions : Assignment - 1
/// Author : Zaina Shahid
/// Student ID : 34669919
/// File : Main.cpp


#include "Weather.h"
#include "Statistics.h"
#include "DateTimeIO.h"

#include <iostream>
#include <cmath>
#include <string>
#include <fstream>
#include <sstream>

// Function prototypes

// Process the user's menu choice
void ProcessChoice(WeatherLogType& weatherData, int ch);

// Get month input from the user
int monthInput();

// Get year input from the user
int yearInput();

// Read weather data from a file
WeatherLogType readData();

int main()
{
    WeatherLogType weather_data = readData();

      if (weather_data.GetSize() == 0)
    {
        std::cout << "No data was loaded. Exiting program." << std::endl;
        return 1;
    }


    int choice;
    while (true)
    {
        std::cout<< "Weather Record Stats Menu:\n";
        std::cout<<"                               \n";
        std::cout<< "1. Average Wind Speed and Sample Standard Deviation For a specified Month and Year.\n";
        std::cout<<"                               \n";
        std::cout<< "2. Average Ambient Air Temperature and Sample Standard Deviation for each Month of a specified Year.\n";
        std::cout<<"                               \n";
        std::cout<< "3. Total Solar Radiation in kWh/m2 for each Month of a specified Year.\n";
        std::cout<<"                               \n";
        std::cout<< "4. Average Wind speed (km/h), Average Ambient Air Temperature, \n";
        std::cout<< "and Total Solar Radiation in kWh/m2 for each Month of a specified Year.\n";
        std::cout<<"                               \n";
        std::cout<< "5. Exit the program.\n";
        std::cout<<"                               \n";
        std::cout<< "Enter your choice: ";
        std::cin >> choice;

         if(choice == 5)
        {
            std::cout << "Exiting the Program." <<std::endl;
            break;
        }

        ProcessChoice(weather_data, choice);


    }

    return 0;

}



void ProcessChoice(WeatherLogType& weatherData, int ch)
{
    // creating a statistics object
    Statistics stats;
    int year;
    int month;


    switch (ch)
   {
       case 1:
           year = yearInput();
           month = monthInput();
           stats.CalculateAndPrintAverageWindSpeedAndStdDev(weatherData,year,month);
           break;
       case 2:
           year = yearInput();
           stats.CalculateAndPrintAverageAmbientAirTemperatureAndStdDev(weatherData,year);
           break;
       case 3:
           year = yearInput();
           stats.CalculateAndPrintTotalSolarRadiation(weatherData,year);
           break;
       case 4:
           year = yearInput();
           stats.CalculateAndGenerateWindTempSolarReport(weatherData, year);
           std::cout << "Report generated: WindTempSolar.csv" << std::endl;
           std::cout<<"                               \n";
           break;
       case 5:
            return;
       default:
             std::cout<< "Invalid Choice. Please Try again. \n";

   }

}


// functions to handle and validate user input for month and year

int monthInput()
 {
    int month;
    std::cout << "Enter the month (1-12): ";
    std::cin >> month;
    while (month < 1 || month > 12)
    {
        std::cout << "Invalid month. Please enter a number between 1 and 12: ";
        std::cin >> month;
    }
    return month;
}


int yearInput()
 {
    int year;
    std::cout << "Enter the Year: ";
    std::cin >> year;
    while (year < 0 || year > 2050)
    {
        std::cout << "Invalid year. Please enter a valid year : ";
        std::cin >> year;
    }
    return year;
}


// function to read data from the csv file
WeatherLogType readData()
{

    // opens the hard coded data_source.txt

    std::string fname;
    std::ifstream DataSourceFile("data/data_source.txt");
    if(!DataSourceFile)
    {
        std::cerr << "Error opening data_source.txt" << std::endl;
        return WeatherLogType(); // return empty WeatherLogType
    }


    DataSourceFile >> fname;
    DataSourceFile.close();

    // Add the directory path to the file name
    fname = "data/" + fname;

    // WeatherLogType object is created to store data
    WeatherLogType weatherData;
    std::ifstream file(fname);

    if(!file)
    {
        std::cerr << "Error opening " << fname << std::endl;
        return WeatherLogType();
    }

    // handle the first line of the file
    bool skipHeader = true;
    std::string line;
    Vector<std::string> ColumnHeaders;
    int wastCol = -1, sCol = -1, srCol = -1, tCol = -1;

    while(std::getline(file, line))
    {
        if(skipHeader)
        {
            skipHeader = false;
            std::istringstream str(line);
            std::string field;
            int colIndex = 0;

            // splits the line by commas and stores each field in ColoumnHeaders
            while(std::getline(str, field, ','))
            {
                ColumnHeaders.Insert(field);
                if(field == "WAST") wastCol = colIndex;
                else if(field == "S") sCol = colIndex;
                else if(field == "SR") srCol = colIndex;
                else if(field == "T") tCol = colIndex;
                colIndex++;
            }

            if(wastCol == -1 || sCol == -1 || srCol == -1 || tCol == -1)
            {
                std::cerr << "Error: Required columns not found" << std::endl;
                return WeatherLogType();
            }

            continue;
        }

        //istringstream is a stream class that allow us to extract data from a string

        std::istringstream str(line);
        std::string field;

        // creates a WeatherRecordsType object to store data
        WeatherRecordsType weatherRec;
        int currentCol = 0;

        while(std::getline(str, field, ','))
        {
            if(currentCol == wastCol)
            {
               std::istringstream DateTimeStream(field);
               DateTimeStream >> weatherRec.d >> weatherRec.t;
            }
            else if(currentCol == sCol)
            {
                try
                {   // using stof to convert to float
                    weatherRec.wind_speed = std::stof(field);
                }
                catch(const std::invalid_argument& e)
                {
                    std::cerr << "Error: invalid wind speed value: " << field << std::endl;
                    break; // skip this record
                }
            }
            else if(currentCol == srCol)
            {
                try
                {
                    weatherRec.solar_radiations = std::stof(field);
                }
                catch(const std::invalid_argument& e)
                {
                    std::cerr << "Error: invalid solar radiation value: " << field << std::endl;
                    break; // skip this record
                }
            }
            else if(currentCol == tCol)
            {
                try
                {
                    weatherRec.amb_temp = std::stof(field);
                }
                catch(const std::invalid_argument& e)
                {
                    std::cerr << "Error: invalid ambient air temperature value: " << field << std::endl;
                    break; // skip this record
                }
            }

            currentCol++;
        }

        if(currentCol == ColumnHeaders.GetSize())
        {
            // Only add the record if we've processed all columns
            weatherData.Insert(weatherRec);
        }
    }

    return weatherData;


    }
















