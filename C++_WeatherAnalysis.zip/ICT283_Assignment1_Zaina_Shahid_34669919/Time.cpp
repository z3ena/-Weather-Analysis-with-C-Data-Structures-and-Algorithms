/// Author : Zaina Shahid
/// Student ID : 34669919
/// File : Implementation File Time.cpp

#include "Time.h"
#include <string>

Time::Time()
{
    hour = 0;
    mins = 0;
}
Time::Time(unsigned int h, unsigned int m)
{
    hour = h;
    mins = m;
}

int Time::GetHour() const
{
    return hour;
}
int Time::GetMinute() const
{
    return mins;
}

void Time::SetHour(unsigned int h)
{
    hour = h;
}
void Time::SetMinute(unsigned int m)
{
    mins = m;
}

std::string Time::TIME_24Format() const
{
    std::string time;
    if(hour < 10)
    {
        time += "0" + std::to_string(hour);
    }
    else
    {
        time += std::to_string(hour);
    }
    time += ":";
    if(mins < 10)
    {
        time += "0" + std::to_string(mins);
    }
    else
    {
        time += std::to_string(mins);
    }

    return time;
}
