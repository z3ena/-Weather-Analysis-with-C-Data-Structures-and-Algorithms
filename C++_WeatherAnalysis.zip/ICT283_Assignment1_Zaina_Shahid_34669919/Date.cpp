/// Author : Zaina Shahid
/// Student ID : 34669919
/// File : Implementation File Date.cpp

#include "Date.h"
#include <string>
using namespace std;

Date::Date()
{
    day = 0;
    month = 0;
    year = 0;
}


Date::Date(unsigned int d, unsigned int m, unsigned int y)
{
    day = d;
    month = m;
    year = y;
}

 // Accessors and Mutators

void Date::SetDay(unsigned int d)
{
    day = d;
}
int Date::GetDay() const
{
    return day;
}

void Date::SetMonth(unsigned int m)
{
    month = m;
}

int Date::GetMonth() const
{
    return month;
}

void Date::SetYear(unsigned int y)
{
    year = y;
}

int Date::GetYear() const
{
    return year;
}

// returning proper format of the Date

std::string Date::FullDateFormat() const
{
    return std::to_string(day) + "/" + std::to_string(month) + "/" + std::to_string(year);
}
