/**
 * @file Statistics.h
 * @author Zaina Shahid
 * student id : 34669919
 * @brief Provides statistical analysis functions for weather data
 */


#ifndef STATISTICS_H
#define STATISTICS_H

#include "Weather.h"


class Statistics
{


public:

         /**
          * @brief Calculates and prints the average wind speed and standard deviation for a specific year and month
          * @param weatherData  containing the records
          * @param year The year for which to calculate the statistics
          * @param month The month for which to calculate the statistics
          */
    void CalculateAndPrintAverageWindSpeedAndStdDev(const WeatherLogType& weatherData, int year, int month);



         /**
          * @brief Calculates and prints the average ambient air temperature and standard deviation for a specific year
          * @param weatherData The weather data log containing the records
          * @param year The year for which to calculate the statistics
          */
    void CalculateAndPrintAverageAmbientAirTemperatureAndStdDev(const WeatherLogType& weatherData, int year);



         /**
          * @brief Calculates and prints the total solar radiation for a specific year
          * @param weatherData The weather data log containing the records
          * @param year The year for which to calculate the total solar radiation
          */
    void CalculateAndPrintTotalSolarRadiation(const WeatherLogType& weatherData, int year);



         /**
          * @brief Generates a comprehensive report of wind speed, temperature, and solar radiation statistics for a specific year
          * @param weatherData The weather data log containing the records
          * @param year The year for which to generate the report
          */
    void CalculateAndGenerateWindTempSolarReport(const WeatherLogType& weatherData, int year);

private:


         /**
          * @brief Calculates the total of a set of values
          * @param values A vector of float values
          * @return The sum of all values in the vector
          */
    float CalculateTotal(const Vector<float>& values);



         /**
          * @brief Calculates the average of a set of values
          * @param values A vector of float values
          * @return The average of all values in the vector
          */
    float CalculateAvg(const Vector<float>& values);



         /**
          * @brief Calculates the standard deviation of a set of values
          * @param values A vector of float values
          * @param average The pre-calculated average of the values
          * @return The standard deviation of the values
          */
    float CalculateStandardDeviation(const Vector<float>& values, float average);



        /**
         * @brief Converts wind speed from meters per second to kilometers per hour
         * @param windSpeed The wind speed in meters per second
         * @return The wind speed converted to kilometers per hour
         */
    float ConvertWindSpeedFromMStoKMH(float windSpeed);



        /**
         * @brief Converts solar radiation from watts to kilowatt-hours
         * @param solarRadiation The solar radiation in watts
         * @return The solar radiation converted to kilowatt-hours
         */
    float ConvertSolarRadiationFromWtoKWH(float solarRadiation);



        /**
         * @brief Converts a numerical month to its string representation
         * @param month The month as an integer (1-12)
         * @return The name of the month as a string
         */
    std::string IntMonthToString(const int &month);

};


#endif // STATISTICS_H















