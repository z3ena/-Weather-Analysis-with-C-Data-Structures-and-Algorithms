/**
 * @file DateTimeIO.h.
 * @author Zaina Shahid
 * student id : 34669919
 * @brief  handle all I/O operations for Date and Time objects.
 */

#ifndef DATETIMEIO_H
#define DATETIMEIO_H

#include "Date.h"
#include "Time.h"
#include <iostream>


          /**
           * @brief Overloaded input stream operator for Date class
           *
           * Reads a date from the input stream in the format specified by the Date class.
           *
           * @param input The input stream to read from
           * @param D The Date object to store the read date
           * @return Reference to the input stream
           */

std::istream& operator>>(std::istream& input, Date& D);

          /**
           * @brief Overloaded output stream operator for Date class
           *
           * Writes a date to the output stream in the format specified by the Date class.
           *
           * @param os The output stream to write to
           * @param D The Date object to be written
           * @return Reference to the output stream
           */
std::ostream& operator<<(std::ostream& os, const Date& D);



            /**
             * @brief Overloaded input stream operator for Time class
             *
             * Reads a time from the input stream in the format specified by the Time class.
             *
             * @param input The input stream to read from
             * @param T The Time object to store the read time
             * @return Reference to the input stream
             */

std::istream& operator>>(std::istream& input, Time& T);


            /**
             * @brief Overloaded output stream operator for Time class
             *
             * Writes a time to the output stream in the format specified by the Time class.
             *
             * @param os The output stream to write to
             * @param T The Time object to be written
             * @return Reference to the output stream
             */
std::ostream& operator<<(std::ostream& os, const Time& T);





#endif
